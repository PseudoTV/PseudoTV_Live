#   Copyright (C) 2023 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from globals    import *
from m3u        import M3U
from xmltvs     import XMLTVS

class Record:
    def __init__(self, sysARG, writer):
        log('Record: __init__, sysARG = %s, writer = %s'%(sysARG,writer))
        self.sysARG = sysARG
        self.writer = writer
        
        
    def add(self):
        with busy_dialog():
            if isBuilding(): 
                DIALOG.notificationDialog(LANGUAGE(32057)%(ADDON_NAME))
            else:
                setWorking(True)
                m3u   = M3U()
                xmltv = XMLTVS()
                mitem = m3u.getRecordItem(self.writer)
                if m3u.addRecording(mitem):
                    if xmltv.addRecording(mitem,self.writer):
                        DIALOG.notificationDialog('%s\n%s'%(mitem['label'],LANGUAGE(30116)))
                        [xmltv._save(),m3u._save()]
                setWorking(False)
                del m3u
                del xmltv
            
            
    def remove(self):
        with busy_dialog():
            if isBuilding(): 
                DIALOG.notificationDialog(LANGUAGE(32057)%(ADDON_NAME))
            else:
                setWorking(True)
                m3u   = M3U()
                xmltv = XMLTVS()
                mitem = m3u.getRecordItem(self.writer)
                if m3u.delRecording(mitem):
                    if xmltv.delBroadcast(mitem):
                        DIALOG.notificationDialog('%s\n%s'%(mitem['label'],LANGUAGE(30118)))
                        [m3u._save(),xmltv._save()]
                setWorking(False)
                del m3u
                del xmltv
            
            
if __name__ == '__main__': 
    try:    param = sys.argv[1]
    except: param = None
    log('Record: __main__, param = %s'%(param))
    if param == 'add':
        Record(sys.argv,writer=decodeWriter(BUILTIN.getInfoLabel('Writer'))).add()
    elif param == 'del':
        Record(sys.argv,writer=decodeWriter(BUILTIN.getInfoLabel('Writer'))).remove()
    