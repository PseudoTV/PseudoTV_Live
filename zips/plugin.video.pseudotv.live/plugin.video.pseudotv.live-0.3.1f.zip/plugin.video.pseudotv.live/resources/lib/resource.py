#   Copyright (C) 2021 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

from resources.lib.globals     import *

try:
    from PIL                   import Image, ImageStat
    hasPillow = True
except:
    hasPillow = False

def unquoteImage(imagestring):
    # imagestring = http://192.168.0.53:8080/image/image%3A%2F%2Fsmb%253a%252f%252f192.168.0.51%252fTV%252fCosmos%2520A%2520Space-Time%2520Odyssey%252fposter.jpg%2F
    # extracted thumbnail images need to keep their 'image://' encoding
    if imagestring.startswith('image://') and not imagestring.startswith(('image://video', 'image://music')):
        return unquote(imagestring[8:-1])
    return imagestring

def quoteImage(imagestring):
     # imagestring = http://192.168.0.53:8080/image/image%3A%2F%2Fsmb%253a%252f%252f192.168.0.51%252fTV%252fCosmos%2520A%2520Space-Time%2520Odyssey%252fposter.jpg%2F                                                   
    if imagestring.startswith('image://'): return imagestring
    # Kodi goes lowercase and doesn't encode some chars
    result = 'image://{0}/'.format(quote(imagestring, '()!'))
    result = re.sub(r'%[0-9A-F]{2}', lambda mo: mo.group().lower(), result)
    return result

class Resources:
    IMG_EXTS = ('.png','.jpg','.gif') #todo convert all formats to png.
    TEXTURES = 'Textures.xbt'

    def __init__(self, jsonRPC):
        self.log('__init__')
        self.jsonRPC     = jsonRPC
        self.cache       = jsonRPC.cache
        self.pool        = jsonRPC.pool
        
        self.logoQueue   = PriorityQueue()
        self.logoThread  = threading.Timer(1.0, self.runQueue)
        self.logoSets    = self.buildLogoResources()
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def buildLogoResources(self):
        self.log('buildLogoResources')#build all logo resources into dict. array.
        local_folder = [{'id':pack,'version':getInstanceID(),'items':self.walkDirectory(pack,checksum=getInstanceID())} for pack in [IMAGE_LOC,LOGO_LOC]]#LOGO_LOC
        
        show_pack = local_folder.copy()  #todo add tvshow logos to show_pack
        # show_pack.extend([{'id':pack,'version':ADDON_VERSION,'items':self.walkResource(pack)} for pack in SETTINGS.getSetting('Resource_Logos').split('|')])
        
        user_pack  = show_pack.copy()
        user_pack.extend([{'id':pack,'version':ADDON_VERSION,'items':self.walkResource(pack)} for pack in SETTINGS.getSetting('Resource_Logos').split('|')])
        
        studios = ["resource.images.studios.white", "resource.images.studios.coloured"]
        if bool(SETTINGS.getSettingInt('Color_Logos')): studios.reverse()
        studios_pack = user_pack.copy()
        studios_pack.extend([{'id':pack,'version':self.jsonRPC.getPluginMeta(pack).get('version',ADDON_VERSION),'items':self.walkResource(pack)} for pack in studios])
        
        genres_pack = user_pack.copy()
        genres_pack.extend([{'id':pack,'version':self.jsonRPC.getPluginMeta(pack).get('version',ADDON_VERSION),'items':self.walkResource(pack)} for pack in ["resource.images.moviegenreicons.transparent"]])

        music_pack = user_pack.copy()
        music_pack.extend([{'id':pack,'version':self.jsonRPC.getPluginMeta(pack).get('version',ADDON_VERSION),'items':self.walkResource(pack)} for pack in ["resource.images.musicgenreicons.text"]])

        custom_pack = user_pack.copy() + studios_pack.copy() + genres_pack .copy()+ music_pack.copy()
        custom_pack = removeDUPSLST(custom_pack)
        
        return {LANGUAGE(30002):{'label':"TV Networks"  ,'packs':studios_pack},
                LANGUAGE(30003):{'label':"TV Shows"     ,'packs':show_pack},
                LANGUAGE(30004):{'label':"TV Genres"    ,'packs':genres_pack},
                LANGUAGE(30005):{'label':"Movie Genres" ,'packs':genres_pack},
                LANGUAGE(30007):{'label':"Movie Studios",'packs':studios_pack},
                LANGUAGE(30006):{'label':"Mixed Genres" ,'packs':genres_pack},
                LANGUAGE(30097):{'label':"Music Genres" ,'packs':music_pack},
                LANGUAGE(30026):{'label':"Recommended"  ,'packs':user_pack},
                LANGUAGE(30033):{'label':"Imports"      ,'packs':user_pack},
                LANGUAGE(30080):{'label':"Mixed"        ,'packs':user_pack},
                LANGUAGE(30320):{'label':"Local"        ,'packs':local_folder,
                LANGUAGE(30171):{'label':"Custom"       ,'packs':custom_pack}}}


    def walkResource(self, id): #convert path from id to vfs, include version checksum 4 cache expiration
        return self.walkDirectory(os.path.join('special://home/addons/%s'%id,'resources'),self.jsonRPC.getPluginMeta(id).get('version',ADDON_VERSION))


    def walkDirectory(self, path, checksum=ADDON_VERSION): #recursively walk all folders, parse xbt textures.
        def _parseXBT():
            resource = path.replace('/resources','').replace('special://home/addons/','resource://')
            walk.setdefault(path,[]).extend(self.jsonRPC.getListDirectory(resource,checksum,expiration)[1])
            return walk
            
        walk = dict()
        path = path.replace('\\','/')
        self.log('walkDirectory, path = %s'%(path))
        expiration  = datetime.timedelta(days=28)
        dirs, files = self.jsonRPC.getListDirectory(path,checksum,expiration)
        if self.TEXTURES in files: return _parseXBT()
        else: walk.setdefault(path,[]).extend(list(filter(lambda f:f.endswith(self.IMG_EXTS),files)))
        for dir in dirs: walk.update(self.walkDirectory(os.path.join(path, dir)))
        return walk
            
            
    def buildImagebase(self):
        port     = 80
        username = 'kodi'
        password = ''
        secure   = False
        enabled  = True
        settings = (self.jsonRPC.getSetting('control','services') or [])
        for setting in settings:
            if setting['id'] == 'services.webserver' and not setting['value']:
                enabled = False
                break
            if setting['id'] == 'services.webserverusername':
                username = setting['value']
            elif setting['id'] == 'services.webserverport':
                port = setting['value']
            elif setting['id'] == 'services.webserverpassword':
                password = setting['value']
            elif setting['id'] == 'services.webserverssl' and setting['value']:
                secure = True
            username = '{0}:{1}@'.format(username, password) if username and password else ''
            
        if enabled:
            protocol = 'https' if secure else 'http'
            return '{0}://{1}localhost:{2}/image/'.format(protocol, username, port)
            # http://192.168.0.53:8080/image/image%3A%2F%2Fsmb%253a%252f%252f192.168.0.51%252fTV%252fCosmos%2520A%2520Space-Time%2520Odyssey%252fposter.jpg%2F
            
            
    def getNamePatterns(self, chname, type):
        return list(set([chname,stripRegion(chname),splitYear(chname)[0],cleanChannelSuffix(chname, type),slugify(chname)]))

        
    def cleanLogoPath(self, logo=''):
        if logo is None: return logo
        realPath = xbmcvfs.translatePath('special://home/addons/')
        if logo.startswith(realPath): #convert real path. to vfs
            logo = logo.replace(realPath,'special://home/addons/').replace('\\','/')
        return logo
               

    def findFuzzyMatch(self, chname, lst, multi=False, THLD=90):
        if lst:
            try:
                if multi: 
                    match = FuzzyProcess.extract(chname, lst)
                    if match: return match
                else:          
                    match = FuzzyProcess.extractOne(chname, lst)
                    if match[1] >= THLD: return match
            except Exception as e: 
                self.log("findFuzzyMatch, failed! %s"%str(e), xbmc.LOGERROR)


    def fuzzyMatchResource(self, pack, chname, multi=False):
        print('fuzzyMatchResource',pack)
        def _match(path, items):
            matches = self.findFuzzyMatch(chname,items.get(path,[]),multi)
            if matches: return path,matches

        cacheName = 'fuzzyMatchResource.%s.%s.%s'%(chname,multi,getMD5(dumpJSON(pack)))
        results   = self.cache.get(cacheName)
        if not results:
            items   = pack.get('items',{})
            print('fuzzyMatchResource',items.keys(),items)
            matches = self.pool.poolList(_match,items.keys(),kwargs={'items':items})
            
            if matches and isinstance(matches,(list,tuple,dict)): 
                results = matches[0]
                self.cache.set(cacheName,results,expiration=datetime.timedelta(days=28))
        return results
            
            
    def fuzzyMatchResources(self, chname, packs, sort=True, all_packs=False, return_all=False):
        matches = []
        for pack in packs:
            match = self.fuzzyMatchResource(pack, chname)
            if match: 
                matches.append(match)
                if not all_packs: break
                 
        if matches:
            if sort:
                matches = (sorted(matches, key=lambda x: x[1][1])) #sort high-lowest match score.
                matches.reverse()
            if not return_all: matches = matches[0]
        #matches = [('special://home/addons/resource.images.studios.white/resources', ('bbc america.png', 95))]
        return matches
        

    def matchLogo(self, chname, type, fuzzy=True):
        chnames = self.getNamePatterns(chname,type)
        for chname in chnames:
            if fuzzy:
                match = self.fuzzyMatchResources(chname, self.logoSets[type].get('packs',[]))#packs by type
            else:
                match = self.matchResource(chname, self.logoSets[type].get('packs',[]))#packs by type
            if match: return match
                

    def matchLocal(self, chname, type):
        return self.fuzzyMatchResources(chname, self.logoSets['Local'].get('packs',[]))#packs by type

            
    def matchResource(self, chname, packs):
        def _match(data):
            path, items = data
            for file in items:
                if '%s.png'%(chname).lower() == file.lower():
                    return (path,[(file,100)])
                    
        def _parse(pack,chname):
            cacheName = 'matchResource.%s.%s'%(chname,getMD5(dumpJSON(pack)))
            results   = self.cache.get(cacheName)
            if not results:
                items   = pack.get('items',{})
                matches = list(filter(None,map(_match,zip(items.keys(),repeat(items)))))
                if matches and isinstance(matches,(list,tuple,dict)): 
                    results = matches[0]
                    self.cache.set(cacheName,results,expiration=datetime.timedelta(days=28))
            return results

        matches = self.pool.poolList(_parse,packs,kwargs={'chname':chname})
        return matches
            
            
    def parseLocal(self, chname):
        for ext in self.IMG_EXTS:
            logo = '%s%s'%(chname,ext)
            if FileAccess.exists(logo):
                return logo


    def parseItem(self, chname, item):
        logo = item.get('logo')
        if logo and logo != LOGO and not logo.startswith(LOGO_LOC):
            if FileAccess.exists(logo): return logo


    def parseLogo(self, chname, type):
        def cleanFuzzyLogo(logo):
            if isinstance(logo,(list,tuple)):
                logo = os.path.join(logo[0],logo[1][0])
            return logo

        #Resource Packs
        logo = self.matchLogo(chname,type)
        if logo: return cleanFuzzyLogo(logo)
        

    def getLogo(self, chname, type=LANGUAGE(30171), path='', item={}, featured=False): 
        self.log('getLogo: chname = %s, type = %s'%(chname,type))
        logo = self.parseLocal(chname)
        if logo: return logo
        logo = self.parseItem(chname, item)
        if logo: return logo
        return (self.parseLogo(chname, type) or LOGO)
        

    def runQueue(self):
        while not self.jsonRPC.inherited.monitor.abortRequested():
            if self.jsonRPC.inherited.monitor.waitForAbort(.5) or self.logoQueue.empty(): break
            chname, type = self.logoQueue.get()[1]
            logo = self.parseLogo(chname, type)
            if logo:
                if logo.startswith('http'):
                    downloadImage(logo,os.path.join(LOGO_LOC,'%s.png'%(chname)))
                else:
                    FileAccess.copy(logo,os.path.join(LOGO_LOC,'%s.png'%(chname)))
        
        
    def startSpooler(self):
        if not self.logoThread.is_alive():
            self.logoThread = threading.Timer(1.0, self.runQueue)
            self.logoThread.name = "logoThread"
            self.logoThread.start()

    # @cacheit()
    # def findTVLogo(self, chname):
        # self.log('findTVLogo: chname = %s'%(chname))
        # def findMatch(item):
            # for pattern in patterns:
                # if item.get('label','').lower() == pattern.lower():
                    # return self.cleanLogoPath(item.get('logo',''))
        
        # items    = self.jsonRPC.getTVshows()
        # patterns = [chname, splitYear(chname)[0]]
        # for item in items:
            # match = findMatch(item)
            # if match: 
                # self.log('findTVLogo, found = %s'%(match))
                # return match
        
        

    # def buildBCTresource(self, type, path, media='video'):
        # self.log('buildBCTresource, type = %s, path = %s, media = %s'%(type,path,media))
        # if path.startswith(('resource://')):
            # version = self.jsonRPC.getPluginMeta(path).get('version',ADDON_VERSION)
        # else: 
            # version = ADDON_VERSION
        # if type in PRE_ROLL: 
            # force = True
        # else: 
            # force = False
        # return self.jsonRPC.listVFS(cleanResourcePath(path),media,force,version)


    # def buildResourceType(self, type, paths):
        # for resource in paths:
            # yield self.getPlayablePaths(type,resource)
        
        
    # def getPlayablePaths(self, type, resource):
        # self.log('getPlayablePaths, type = %s, resource = %s'%(type,resource))
        # if not resource.startswith('resource://'): resource = 'resource://%s'%(resource)
        # tmpdict = dict()
        # items   = list(self.buildBCTresource(type, resource))
        # for item in items:
            # folder = os.path.basename(os.path.normpath(item.get('path','')))
            # if folder and folder != 'resources': 
                # tmpdict.setdefault(folder.lower(),[]).append(item)
            # else:
                # if type == "ratings":
                    # tmpdict.setdefault(os.path.splitext(item.get('label'))[0].lower(),{}).update(item)
                # else:
                    # tmpdict.setdefault('root',[]).append(item)
        # return tmpdict


                
        # elif logo.startswith('resource://'):
            # path, file = os.path.split(logo)
            # return path.replace('resource:\\','special://home/addons/') + '/resources/%s'%(file)
        # if logo.startswith(ADDON_PATH):
            # logo = logo.replace(ADDON_PATH,'special://home/addons/%s/'%(ADDON_ID)).replace('\\','/')
        # if featured:
            # localIcon = os.path.join(LOGO_LOC,'%s.png'%(channelname))
            # if logo.startswith('resource://'): return logo #todo parse xbt and extract image?
            # # if FileAccess.copy(logo, localIcon): return localIcon
        # return logo


    # def parseDirectory(self, path, name, patterns=None):
        # if patterns is None: patterns = self.getNamePatterns(name)
        # dirs, files = self.jsonRPC.getListDirectory(path)
        # for pattern in patterns:
            # for file in files:
                # if file == pattern:
                    # return self.cleanLogoPath(os.path.join(path,pattern))
            # for dir in dirs:
                # if dir == os.path.splitext(pattern)[0]:
                    # return self.chkDirectory4Logo(dir,name,patterns)
        # return None

    
    # def buildLocalTrailers(self, path=None, items=[]):
        # self.log('buildLocalTrailers, path = %s, items = %s'%(path,len(items)))
        # if path is None and len(items) > 0:
            # return [{'label':item.get('label',''),'duration':self.parseDuration(item.get('trailer',''),item),'file'}]
        # list(filter(lambda item:(,item.get('trailer')), validItems))
# # os.path.splitext(os.path.basename(item.get('file')))[0]

     # def buildResourcePath(self, path, file):
        # if path.startswith('resource://'):
            # path = path.replace('resource://','special://home/addons/') + '/resources/%s'%(file)
        # else: 
            # path = os.path.join(path,file)
        # return path
        
    # resourceMap = {'path':path,'files':files,'dirs':dirs,'filepaths':files}
    # resourceMap = {'path':path,'files':files,'dirs':dirs,'filepaths':[self.buildResourcePath(path,file) for file in files]}
        

    # def chkMono(self, logo):
        # try:
            # dest = os.path.join(LOGO_MONO_LOC,'w%s'%(os.path.split(xbmcvfs.translatePath(logo))[1]))
            # if FileAccess.exists(dest): return dest
            # return self.monoConvert(logo,dest,bool(SETTINGS.getSettingInt('Color_Logos')))
        # except Exception as e: self.log("chkMono, failed! " + str(e), xbmc.LOGERROR)
        # return logo
            

    # def monoConvert(self, logo, dest, useColor=bool(SETTINGS.getSettingInt('Color_Logos'))):
        # return logo
        # self.log('monoConvert, logo = %s, dest = %s'%(logo,dest)) #detect if logo is color and if preference is mono, covert to mono.
        # pil_img = Image.open(FileAccess.translatePath(logo))
        # # pil_img = Image.open(FileAccess.open(logo,"r"))
        # def isColor(adjust_color_bias=True):
            # bands = pil_img.getbands()
            # if bands == ('R','G','B') or bands== ('R','G','B','A'):
                # thumb = pil_img.resize((40,40))
                # SSE, bias = 0, [0,0,0]
                # if adjust_color_bias:
                    # bias = ImageStat.Stat(thumb).mean[:3]
                    # bias = [b - sum(bias)/3 for b in bias ]
                # for pixel in thumb.getdata():
                    # mu = sum(pixel)/3
                    # SSE += sum((pixel[i] - mu - bias[i])*(pixel[i] - mu - bias[i]) for i in [0,1,2])
                # MSE = float(SSE)/(40*40)
                # if MSE <= 22: return False #grayscale
                # else: return True#Color
            # elif len(bands)==1: return False #Mono"
            # else: return True #Undetermined
            
        # if not hasPillow: return logo
        # if isColor(logo) and useColor:
            # img_bright = ImageEnhance.Brightness(pil_img.convert('LA'))
            # converted_img = img_bright.enhance(2.0)
            # converted_img.save(dest)
            # return dest
        # return logo