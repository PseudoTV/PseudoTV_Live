#   Copyright (C) 2020 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# https://bitbucket.org/jfunk/python-xmltv/src/default/README.txt
# https://github.com/kodi-pvr/pvr.iptvsimple/blob/Matrix/README.md#m3u-format-elements

# -*- coding: utf-8 -*-

from resources.lib.globals import *
from config                import Config
from resources.lib.parser  import JSONRPC, Channels

class Manager:
    def __init__(self, sysARG):
        log('Manager: __init__, sysARG = ' + str(sysARG))
        setBusy(False)
        self.sysARG        = sysARG
        self.madeChange    = False
        self.myMonitor     = MY_MONITOR
        self.config        = Config(self.sysARG)
        self.channels      = Channels()
        self.jsonRPC       = JSONRPC()
        self.cache         = self.jsonRPC.cache
        self.channelLimit  = CHANNEL_LIMIT
        self.newChannel    = self.getTemplate()
        self.channelList   = sorted(self.createChannelList(self.buildArray(), self.getChannels()), key=lambda k: k['number'])
        self.newChannels   = self.channelList.copy()
        self.buildChannelListItems()
        
        
    def settingsChanged(self):
        return self.channelList != self.newChannels
        
            
    def getChannels(self):
        log('Manager: getChannels')
        return self.channels.channelList.get('channels',[])
        

    def saveChannels(self):
        log('Manager: saveChannels')
        if not self.settingsChanged(): return
        if not yesnoDialog(LANGUAGE(30073)): return
        [self.channels.add(channel) for channel in self.newChannels]
        self.channels.save()
        return True
        

    def addChannel(self, item):
        log('Manager: addChannel, item = %s'%(item))
        if not self.madeChange: return
        # if not yesnoDialog('Update Channel?'): return
        print(self.channelList,self.channelList['channels'],type(self.channelList['channels']))
        print(self.newChannels,self.newChannels['channels'],type(self.newChannels['channels']))
        newChannels = self.newChannels['channels']
        for channel in newChannels:
            if item["number"] == channel["number"]:
                log('Manager: Updating channel %s settings'%(item["number"]))
                newChannels.update(item)
                return True
        log('Manager: Adding channel %s settings'%(item["number"]))
        newChannels.append(channel)
        self.newChannels['channels'] = newChannels
        self.madeChange = False
        
        
    @use_cache(28)
    def getTemplate(self):
        log('Manager: getTemplate')
        return self.channels.load(CHANNELFLE_DEFAULT).get('channels',[])[0]
        
        
    def buildArray(self):
        log('Manager: buildArray')
        for idx in range(self.channelLimit):
            newChannel = self.newChannel.copy()
            newChannel['number'] = idx + 1
            yield newChannel
                
                
    def createChannelList(self, channelArray, channelList):
        log('Manager: createChannelList')#todo elegant solution? 
        for item in channelArray:
            for channel in channelList:
                if item["number"] == channel["number"]:
                    item.update(channel)
                yield item
                 
                     
    def buildChannelListItem(self, channel):
        label  = '%s: %s'%(channel["number"],channel["name"])
        label2 = '%s: %s'%(channel["type"],' / '.join(channel["genre"])) if channel["type"] else ''
        return buildMenuListItem(label,label2,channel["logo"],'|'.join(channel["path"]),propItem={'writer':dumpJSON(channel, sortkey=False)})
        
        
    def buildChannelListItems(self):
        log('Manager: buildChannelListItems')
        with busy_dialog():
            listItems = list(PoolHelper().poolList(self.buildChannelListItem,self.channelList))
        select = selectDialog(listItems,'%s: %s'%(ADDON_NAME,LANGUAGE(30072)), multi=False)
        
        if select >= 0: 
            self.buildChannelItem(listItems[select])
            
        if self.saveChannels(): 
            REAL_SETTINGS.openSettings()
        
        
    def buildChannelItem(self, data):
        if isBusy(): 
            return notificationDialog(LANGUAGE(30029)%(ADDON_NAME))
        setBusy(True)
        log('Manager: buildChannelItem')
        # {"number": 1, "type": "", "name": "", "logo": "", "path": [], "genre": [], "rules": []}
        channelData = loadJSON(data.getProperty('writer'))
        select = 0
        while select > -1 and not self.myMonitor.abortRequested():
            listItems = []
            for key, value in channelData.items():
                if key in ["number"]: continue # keys to ignore
                if not value: value = ''
                listItems.append(buildMenuListItem('%s'%(value),'%s'%(key.title()),channelData["logo"]))
            select = selectDialog(listItems,'%s: %s'%(ADDON_NAME,LANGUAGE(30072)), multi=False)
            if select > -1: 
                channelData = self.itemInput(listItems[select].getLabel(), listItems[select].getLabel2(), channelData) #todo set value
        setBusy(False)
        self.addChannel(channelData)
        self.buildChannelListItems()
        
        
    def itemInput(self, value, key, channelData):
        log('Manager: itemInput, value = %s, key = %s'%(value,key))
        KEY_INPUT = {"type" : {'func':selectDialog    ,'args':()},
                     "name" : {'func':inputDialog     ,'args':('Enter Channel Name',value)},
                     "logo" : {'func':selectDialog    ,'args':()},
                     "path" : {'func':selectDialog    ,'args':()},
                     "genre": {'func':selectDialog    ,'args':(GENRE_TYPES,'Select Channel Genres',0,None,False,True)},
                     "rules": {'func':self.selectRules,'args':()}}
                     
        args   = KEY_INPUT[key.lower()]['args']
        retval = KEY_INPUT[key.lower()]['func'](*args)
        if retval:
            self.madeChange = True
            if isinstance(retval,list):
                retval = ' / '.join([args[0][idx] for idx in retval])
                
            channelData[key.lower()] = retval
        return channelData
        
   
   
    def selectRules(self, channelData):
        log('Manager: selectRules')
    
if __name__ == '__main__': Manager(sys.argv)
        