#   Copyright (C) 2020 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*--

from resources.lib.globals import *

class Predefined:
    def __init__(self, cache=None, config=None):
        self.log('__init__')
        if cache is None:
            self.cache = SimpleCache()
        else: 
            self.cache = cache
            
        if not config: return
        self.myConfig    = config
        self.channels    = self.myConfig.channels
        self.jsonRPC     = self.myConfig.jsonRPC
        self.library     = self.myConfig.library
        self.recommended = self.myConfig.recommended
        
        self.pathTypes  = {LANGUAGE(30002): self.createNetworkPlaylist,
                           LANGUAGE(30003): self.createShowPlaylist,
                           LANGUAGE(30004): self.createTVGenrePlaylist,
                           LANGUAGE(30005): self.createMovieGenrePlaylist,
                           LANGUAGE(30007): self.createStudioPlaylist,
                           LANGUAGE(30006): self.createGenreMixedPlaylist,
                           LANGUAGE(30080): self.createMixedOther,
                           LANGUAGE(30026): self.createRECOMMENDED,
                           LANGUAGE(30097): self.createMusicGenrePlaylist}
                        
        self.mixedPaths = {LANGUAGE(30078): self.createMixedRecent,
                           LANGUAGE(30141): self.createSeasonal,
                           LANGUAGE(30079): self.createPVRRecordings} # home for misc. predefined channel paths.
        
        self.exclude_specials = ',{"field":"season","operator":"greaterthan","value":"0"},{"field":"episode","operator":"greaterthan","value":"0"}'
        log('__init__, exclude_specials = %s'%(self.exclude_specials))
    
    
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)
    

    def createMixedOther(self, type):
        return self.mixedPaths[type]()
        
        
    def createRECOMMENDED(self, type):
        return []
        
    
    def createPVRRecordings(self):
        return 'pvr://recordings/tv/active/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"random"}}'
        
        
    def createMixedRecent(self):
        return ['videodb://recentlyaddedepisodes/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"episode"}}',
                'videodb://recentlyaddedmovies/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"random"}}']
        
        
    def createMusicRecent(self):
        return 'musicdb://recentlyaddedalbums/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"random"}}'
        
        
    def createNetworkPlaylist(self, network, method='episode'):
        return 'videodb://tvshows/studios/-1/-1/-1/-1/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"studio","operator":"is","value":["%s"]}%s]},"type":"episodes"}'%(method,urllib.parse.quote(network),self.exclude_specials)
        

    def createShowPlaylist(self, show, method='episode'):
        match = re.compile('(.*) \((.*)\)', re.IGNORECASE).search(show)
        if match.group(2): #tvshow year filter
            return 'videodb://tvshows/titles/-1/-1/-1/-1/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"year","operator":"is","value":["%s"]},{"field":"tvshow","operator":"is","value":["%s"]}%s]},"type":"episodes"}'%(method,match.group(2),urllib.parse.quote(match.group(1)),self.exclude_specials)
        else:
            return 'videodb://tvshows/titles/-1/-1/-1/-1/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"tvshow","operator":"is","value":["%s"]}%s]},"type":"episodes"}'%(method,urllib.parse.quote(show),self.exclude_specials)


    def createTVGenrePlaylist(self, genre, method='episode'):
        return 'videodb://tvshows/titles/-1/-1/-1/-1/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"genre","operator":"is","value":["%s"]}%s]},"type":"episodes"}'%(method,urllib.parse.quote(genre),self.exclude_specials)


    def createMovieGenrePlaylist(self, genre, method='random'):
        return 'videodb://movies/titles/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"genre","operator":"is","value":["%s"]}]},"type":"movies"}'%(method,urllib.parse.quote(genre))


    def createStudioPlaylist(self, studio, method='random'):
        return 'videodb://movies/titles/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"studio","operator":"is","value":["%s"]}]},"type":"movies"}'%(method,urllib.parse.quote(studio))


    def createMusicGenrePlaylist(self, genre, method='random'):
        return 'musicdb://songs/?xsp={"order":{"direction":"ascending","ignorefolders":0,"method":"%s"},"rules":{"and":[{"field":"genre","operator":"contains","value":["%s"]}]},"type":"music"}'%(method,urllib.parse.quote(genre))


    def createGenreMixedPlaylist(self, genre):
        return [self.createTVGenrePlaylist(genre),self.createMovieGenrePlaylist(genre)]
        
        
    def createSeasonal(self):
        return LANGUAGE(30174)
        
        
    def getChannelPostfix(self, name, type):
        if   type == LANGUAGE(30004): suffix = LANGUAGE(30155) #TV
        elif type == LANGUAGE(30097): suffix = LANGUAGE(30157) #Music
        elif type == LANGUAGE(30005): suffix = '%ss'%(LANGUAGE(30156)) #Movie
        else: return name
        return '%s %s'%(name,suffix)

    
    def buildAvailableRange(self, type, blist, size=1):
        start = ((CHANNEL_LIMIT+1)*(CHAN_TYPES.index(type)+1))
        stop  = (start + CHANNEL_LIMIT)
        return list(set(range(start,stop)).difference(blist))
            

    def findEXChannel(self, citem, type, channels=None):
        self.log('findEXChannel, item = %s, type = %s'%(citem,type))
        if channels is None: channels = self.channels.getPredefinedChannels()
        for idx, item in enumerate(channels):
            if (item['id'] == citem['id']) or (item['type'].lower() == citem['type'].lower() and item['name'].lower() == citem['name'].lower() and item['path'] == citem['path']):
                return idx, item
        return None, {}


    def buildPredefinedChannels(self):
        channels = self.channels.getPredefinedChannels()
        types    = list(filter(lambda k:k != LANGUAGE(30033), CHAN_TYPES))
        for type in types:
            self.log('buildPredefinedList, type = %s'%(type))
            echannels = list(filter(lambda k:k['type'] == type, channels)) # existing channels, avoid duplicates, aid in removal.
            enumbers  = [echannel.get('number') for echannel in echannels if echannel.get('number',0) > 0] #existing channel numbers
            items     = self.library.getLibraryItems(type, enabled=True) #current items
            citems    = sorted(PoolHelper().poolList(self.buildPredefinedChannel,items,type), key=lambda k: k['name'])
            numbers   = iter(self.buildAvailableRange(type,enumbers,len(items))) #list of available channel numbers 
            
            for citem in citems:
                match, eitem = self.findEXChannel(citem, type, echannels)
                if match is not None: #update new citems with existing values.
                    for key in ['rules','number','favorite','page']: citem[key] = eitem[key]
                else: citem['number'] = next(numbers,0)
                citem['id'] = getChannelID(citem['name'], citem['path'], citem['number'])
                self.channels.add(citem)
        self.channels.save()
        return True
        
          
    def buildPredefinedChannel(self, data):
        item, type = data
        if type not in self.pathTypes.keys(): return None
        citem = self.channels.getCitem()
        citem.update({'name'   :self.getChannelPostfix(item['name'], type),
                      'path'   :self.pathTypes[type](item['name']),
                      'type'   :item['type'],
                      'logo'   :item['logo'],
                      'group'  :[type]})
                      
        citem['radio']   = (type == LANGUAGE(30097) or 'musicdb://' in citem['path'])
        citem['catchup'] = ('vod' if not citem['radio'] else '')
        return citem