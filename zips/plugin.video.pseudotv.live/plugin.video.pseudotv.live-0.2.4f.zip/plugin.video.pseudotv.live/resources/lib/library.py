#   Copyright (C) 2020 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

from resources.lib.globals     import *
from resources.lib.fileaccess  import FileLock

REG_KEY = 'PseudoTV_Recommended.%s'

@contextmanager
def fileLocker(GlobalFileLock):
    log('parser: fileLocker')
    GlobalFileLock.lockFile("MasterLock")
    try: yield
    finally: 
        GlobalFileLock.unlockFile('MasterLock')
        GlobalFileLock.close()

class Library:
    def __init__(self, cache=None, config=None):
        log('Library: __init__')
        if cache is None:
            self.cache = SimpleCache()
        else: 
            self.cache = cache
        
        self.TV_Shows          = []
        self.TV_Info           = [[],[]]
        self.MOVIE_Info        = [[],[]]
        self.MUSIC_Info        = []
        self.Recommended_Items = []
        
        self.libraryItems = self.getTemplate(ADDON_VERSION)
        self.libraryItems.update(self.load())
        
        if config:
            self.channels = config.channels
            self.jsonRPC  = config.jsonRPC
        else: return
        
        self.recommended  = Recommended(self.cache, self)
            

    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)
    

    def reset(self):
        self.log('reset')
        self.__init__()
        return True


    @use_cache(7)
    def getTemplate(self, version=ADDON_VERSION):
        log('getTemplate')
        return (self.load(LIBRARYFLE_DEFAULT) or {})


    def load(self, file=LIBRARYFLE):
        self.log('load file = %s'%(file))
        if not FileAccess.exists(file): 
            file = LIBRARYFLE_DEFAULT
        with fileLocker(FileLock()):
            fle  = FileAccess.open(file, 'r')
            data = (loadJSON(fle.read()) or {})
            fle.close()
            return data
        
        
    def save(self):
        with fileLocker(FileLock()):
            fle = FileAccess.open(LIBRARYFLE, 'w')
            self.log('save, saving to %s'%(LIBRARYFLE))
            fle.write(dumpJSON(self.libraryItems, idnt=4, sortkey=False))
            fle.close()
        return self.reset() #force memory/file parity 


    def getLibraryItems(self, type, enabled=False):
        self.log('getLibraryItems, type = %s, enabled = %s'%(type,enabled))
        items = self.libraryItems.get('library',{}).get(type,[])
        if enabled: items = list(filter(lambda k:k.get('enabled',False) == True, items))
        return sorted(items, key=lambda k: k['name'])


    def setLibraryItems(self, type, items):
        self.libraryItems['library'][type] = sorted(items, key=lambda k: k['name'])
        return self.save()


    def setEnableState(self, type, selects):
        items = self.getLibraryItems(type).copy()
        self.log('setEnableState, type = %s, items = %s, selects = %s'%(type, len(items), selects))
        for idx, item in enumerate(items):
            if idx in selects: item['enabled'] = True
            else:              item['enabled'] = False
        return self.setLibraryItems(type,items)


    def buildPredefinedItems(self):        
        busy = ProgressBGDialog(message='%s...'%(LANGUAGE(30158)))
        for idx, type in enumerate(CHAN_TYPES):
            self.log('buildPredefinedItems, type = %s'%(type))
            busy     = ProgressBGDialog((idx*100//len(CHAN_TYPES)), busy, LANGUAGE(30159)%(type))
            existing = self.getLibraryItems(type,enabled=False)
            items    = self.getfillItems(type) #current items
            bpitems  = (PoolHelper().poolList(self.buildPredefinedItem,items,[type,existing]))
            self.setLibraryItems(type, bpitems)
        ProgressBGDialog(100, busy, '%s...'%(LANGUAGE(30158)))
            
            
    def buildPredefinedItem(self, data):
        name, meta = data
        type, existing = meta
        enabled = False
        eitem = list(filter(lambda e:e.get('name','') == name, existing))
        if eitem: enabled = eitem[0].get('enabled',False)
        return {'enabled':enabled,'name':name,'type':type,'logo':self.jsonRPC.getLogo(name, type)}


    def getfillItems(self, type=None):
        #heavy call, all methods init. #todo improve by converting to dict not lists, don't call methods during call.
        items = {LANGUAGE(30002):self.getTVInfo()[0],
                 LANGUAGE(30003):self.getTVShows(),
                 LANGUAGE(30004):self.getTVInfo()[1],
                 LANGUAGE(30005):self.getMovieInfo()[1],
                 LANGUAGE(30007):self.getMovieInfo()[0],
                 LANGUAGE(30006):self.makeMixedList(self.getTVInfo()[1], self.getMovieInfo()[1]),
                 LANGUAGE(30080):self.getMixedMisc(),
                 LANGUAGE(30097):self.getMusicGenres(),
                 LANGUAGE(30026):self.getRecommended(),
                 LANGUAGE(30033):self.getImports()}
        if type is not None: return items[type]
        return items


    def getTVInfo(self):
        if (len(self.TV_Info[0]) == 0 or len(self.TV_Info[1]) == 0): 
            self.TV_Info = self.jsonRPC.getTVInfo()
        self.log('getTVInfo, networks = %s, genres = %s'%(len(self.TV_Info[0]),len(self.TV_Info[1])))
        return self.TV_Info
 
 
    def getTVShows(self):
        if len(self.TV_Shows) == 0: 
            self.TV_Shows = self.jsonRPC.fillTVShows()
        self.TV_Shows.sort(key=lambda x:x['label'])
        shows = [show['label'] for show in self.TV_Shows]
        self.log('getTVShows, found = %s'%(len(shows)))
        return shows
 
 
    def getMovieInfo(self):
        if (len(self.MOVIE_Info[0]) == 0 or len(self.MOVIE_Info[1]) == 0): 
            self.MOVIE_Info = self.jsonRPC.getMovieInfo()
        self.log('getMovieInfo, studios = %s, genres = %s'%(len(self.MOVIE_Info[0]),len(self.MOVIE_Info[1])))
        return self.MOVIE_Info
 

    def makeMixedList(self, genres1, genres2):
        newlist = [genre1 for genre1 in genres1 for genre2 in genres2 if genre1.lower() == genre2.lower()]
        self.log('makeMixedList, genres = %s'%(','.join(newlist)))
        return newlist
        
 
    def getMixedMisc(self):
        return [LANGUAGE(30078),LANGUAGE(30141),LANGUAGE(30079)]
 
        
    def getRecommended(self):
        self.log('getRecommended')
        if len(self.Recommended_Items) == 0: 
            self.Recommended_Items = self.recommended.fillRecommended()
        self.Recommended_Items.sort(key=lambda x:x['item']['name'])
        recommended = [recommended['item']['name'] for recommended in self.Recommended_Items]
        self.log('getRecommended, found = %s'%(len(recommended)))
        return recommended


    def getMusicGenres(self):
        if len(self.MUSIC_Info) == 0: 
            self.MUSIC_Info = self.jsonRPC.fillMusicInfo()
        self.log('getMusicGenres, genres = %s'%(len(self.MUSIC_Info)))
        return self.MUSIC_Info
        
        
    def getImports(self):
        return self.recommended.getImports()
        
        
class Recommended:
    def __init__(self, cache=None, library=None):
        self.log('__init__')
        if cache is None:
            self.cache = SimpleCache()
        else: 
            self.cache = cache

        if not library: return
        self.library  = library
        self.channels = self.library.channels
        self.jsonRPC  = self.library.jsonRPC
    
        self.importPrompt_busy = False
        self.recommendEnabled  = getSettingBool('Enable_Recommended')


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)
    
    
    def reset(self):
        self.log('reset')
        self.__init__()
        return True


    def getRecommendedItems(self):
        return self.library.libraryItems.get('recommended',{})


    def getWhiteList(self):
        #whitelist - prompt shown, added to import list and/or manager dropdown.
        return self.getRecommendedItems().get('whitelist',[])
        
        
    def getBlackList(self):
        #blacklist - plugin ignored for the life of the list.
        return self.getRecommendedItems().get('blacklist',[])
    
    
    def addWhiteList(self, addonid):
        self.log('addWhiteList, addonid = %s'%(addonid))
        whitelist = self.getWhiteList()
        whitelist.append(addonid)
        self.library.libraryItems['recommended']['whitelist'] = list(set(whitelist))
        return True
        

    def addBlackList(self, addonid):
        self.log('addBlackList, addonid = %s'%(addonid))
        blacklist = self.getBlackList()
        blacklist.append(addonid)
        self.library.libraryItems['recommended']['blacklist'] = list(set(blacklist))
        setSetting('Clear_BlackList','|'.join(self.library.libraryItems['recommended']['blacklist']))
        return True
    
    
    def clearBlackList(self):
        self.library.libraryItems['recommended']['blacklist'] = []
        return setSetting('Clear_BlackList','|'.join(self.getBlackList()))


    def searchRecommendedAddon(self, addon):
        addonid   = addon.get('addonid','')
        blackList = self.getBlackList()
        if not addonid in blackList:
            data = xbmcgui.Window(10000).getProperty(REG_KEY%(addonid))
            if data: 
                self.log('searchRecommendedAddon, found addonid = %s, payload = %s'%(addonid,data))
                return {'id':addonid,'data':loadJSON(data),'item':getPluginMeta(addonid)}
            
            
    def searchRecommendedAddons(self):
        self.log('searchRecommendedAddons')
        return (PoolHelper().poolList(self.searchRecommendedAddon, self.jsonRPC.getAddons()))
        
        
    def getRecommendedType(self, type='iptv'):
        self.log('getRecommendedType, type = %s'%(type))
        whiteList = self.getWhiteList()
        recommendedAddons = self.searchRecommendedAddons()
        return [item for item in recommendedAddons for addonid in whiteList if ((item.get('id','') == addonid) and (item['data'].get('type','').lower() == type.lower()))]
        
        
    def fillRecommended(self):
        self.log('fillRecommended')
        whiteList = self.getWhiteList()
        recommendedAddons = self.searchRecommendedAddons()
        return [item for item in recommendedAddons for addonid in whiteList if ((item.get('id','') == addonid) and (item['data'].get('type','').lower() != 'iptv'))]
        
        
    def importPrompt(self):
        self.log('importPrompt')
        if self.importPrompt_busy: return False
        self.importPrompt_busy = True
        ignoreList = self.getWhiteList()
        ignoreList.extend(self.getBlackList())
        recommendedAddons = self.searchRecommendedAddons()
        for addon in recommendedAddons:
            if not addon['id'] in ignoreList:
                if not yesnoDialog('%s'%(LANGUAGE(30147)%(ADDON_NAME,addon['item'].get('name','')))):                   
                    self.addBlackList(addon['id'])
                else:
                    self.addWhiteList(addon['id'])
        self.importPrompt_busy = False
        return True
          
          
    def resetImports(self):
        self.log('resetImports')
        # self.library.libraryItems['imports'] = []
        # return True


    def getImports(self):
        self.log('getImports')
        items = sorted(self.getRecommendedType(),key=lambda x:x['item']['name'])
        iptv = [item.get('item',{}).get('name') for item in items]
        self.log('getImports, found = %s'%(len(iptv)))
        return iptv

    # def getRecommended(self):
        # log('Channels: getRecommended')
        # return self.channelList.get('recommended',{})

        
    # def setRecommended(self, recommended):
        # log('Channels: setRecommended, recommended items = %s'%(len(recommended)))
        # self.channelList['recommended'] = recommended
        # return self.save()

    # def findImport(self, eitem, imports=None):
        # if imports is None:
            # imports = self.library.libraryItems['imports']
        # for idx, item in enumerate(imports):
            # if eitem.get('id','') == item.get('id',''): 
                # self.log('findImport, item = %s, found = %s'%(eitem,item))
                # return idx, item
        # return None, {}
        

    # def addImport(self, eitem):
        # self.log('addImport, item = %s'%(eitem))
        # imports = self.library.libraryItems['imports']
        # idx, item = self.findImport(eitem,imports)
        # if idx is None:
            # imports.append(eitem)
        # else:
            # imports[idx].update(eitem)
        # self.library.libraryItems['library']['imports'] = imports
        # return True