#   Copyright (C) 2020 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from resources.lib.globals     import *
from resources.lib.jsonrpc     import JSONRPC
from resources.lib.parser      import Writer
from resources.lib.predefined  import Predefined 
from resources.lib.library     import Library

class Config:
    def __init__(self, sysARG=sys.argv, cache=None, service=None):
        self.log('__init__, sysARG = ' + str(sysARG))
        self.sysARG    = sysARG
        if cache is None:
            self.cache = SimpleCache()
        else: 
            self.cache = cache

        if service:
            self.jsonRPC     = service.jsonRPC
            self.channels    = service.channels
        else:
            self.jsonRPC     = JSONRPC(self.cache)
            self.channels    = Writer(self.cache).channels
        
        self.library         = Library(self.cache, self)
        self.recommended     = self.library.recommended
        self.predefined      = Predefined(self.cache, self)
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)

            
    def autoTune(self):
        if not yesnoDialog(LANGUAGE(30132)%(ADDON_NAME)): 
            return False
        busy = ProgressBGDialog(message='%s...'%(LANGUAGE(30102)))
        types = CHAN_TYPES.copy()
        types.pop(types.index(LANGUAGE(30033))) #remove "imports" from autotune list
        for idx, type in enumerate(types):
            self.log('autoTune, type = %s'%(type))
            busy = ProgressBGDialog((idx*100//len(CHAN_TYPES)), busy, '%s: %s'%(LANGUAGE(30102),type))
            self.selectPredefined(type,autoTune=3)
            xbmc.sleep(1000)
        ProgressBGDialog(100, busy, '%s...'%(LANGUAGE(30102)))
        return True
 
 
    def selectPredefined(self, type=None, autoTune=None):
        self.log('selectPredefined, type = %s, autoTune = %s'%(type,autoTune))
        setBusy(True)
        escape = autoTune is not None
        with busy_dialog(escape):
            items = self.library.getLibraryItems(type,enabled=False)
            if not items: 
                setBusy(False)
                if autoTune is None:
                    self.setPredefinedSelection(type,[])
                    notificationDialog(LANGUAGE(30103)%(type))
                return
                
            pitems = self.library.getLibraryItems(type,enabled=True) # existing predefined
            listItems = (PoolHelper().poolList(self.buildPoolListitem,items,type))
        if autoTune is None:
            select = selectDialog(listItems,'Select %s'%(type),preselect=findItemsIn(listItems,pitems,val_key='name'))
        else:
            if autoTune > len(items): autoTune = len(items)
            select = random.sample(list(set(range(0,len(items)))),autoTune)
        if select:
            selects = findItemsIn(items,[listItems[idx].getLabel() for idx in select],item_key='name')
            self.library.setEnableState(type,selects)
            self.setPredefinedSelection(type,selects)
            if type == LANGUAGE(30033):
                self.buildImports()
            else:
                self.predefined.buildPredefinedChannels()
        setBusy(False)

        
    def buildImports(self):
        self.log('buildImports')
        items = self.recommended.getRecommendedType()
        imports = self.library.getLibraryItems(LANGUAGE(30033), enabled=True) #current items
        self.channels.setImports([item['data'] for item in items for eimport in imports if ((item.get('data',{}).get('name','').startswith(eimport.get('name'))) and (item['data'].get('type','').lower() == 'iptv'))])
        return self.channels.save()
        

    def buildSelectionSettings(self, reset=False):
        for type in CHAN_TYPES:
            self.log('buildSelectionSettings, type = %s'%(type))
            if reset: items = []
            else:     items = self.library.getLibraryItems(type, enabled=True)
            self.setPredefinedSelection(type,items)
            
            if len(self.library.getLibraryItems(type)) > 0: 
                  setProperty('has.%s'%(type.replace(' ','_')),'true')
            else: setProperty('has.%s'%(type.replace(' ','_')),'false')
        
        setSetting('Clear_BlackList','|'.join(self.recommended.getBlackList()))
        

    def setPredefinedSelection(self, type, items):
        self.log('setPredefinedSelection, type = %s, items = %s'%(type,items))
        # setSetting('Clear_Predefined','(%s) Channels'%(len(self.channels.getPredefinedChannels())))
        return setSetting('Select_%s'%(type.replace(' ','_')),'(%s) Selected'%(len(list(filter(lambda x: x != '',items)))))
        

    def clearPredefined(self):
        self.log('clearPredefined')
        # clear predefined selections for all types.
        if not yesnoDialog('%s?'%(LANGUAGE(30077))): return
        setBusy(True)
        [self.library.setEnableState(type,[]) for type in CHAN_TYPES]
        self.buildSelectionSettings(items=[])
        setBusy(False)
        return notificationDialog(LANGUAGE(30053))


    def clearUserChannels(self):
        self.log('clearUserChannels') 
        if not yesnoDialog('%s?'%(LANGUAGE(30093))): return
        if FileAccess.delete(CHANNELFLE):
            return notificationDialog(LANGUAGE(30016)%(LANGUAGE(30024)))


    def clearBlackList(self):
        self.log('clearBlackList') 
        if not yesnoDialog('%s?'%(LANGUAGE(30154))): return
        return self.recommended.clearBlackList()
        

    def userGroups(self):
        self.log('userGroups')
        retval = inputDialog(LANGUAGE(30076), default=getSetting('User_Groups'))
        if not retval: return
        setSetting('User_Groups',retval)
        notificationDialog(LANGUAGE(30053))


    def clearImport(self):
        self.log('clearImport') 
        with busy_dialog():
            setSetting('Import_M3U','')
            setSetting('Import_XMLTV','')
            setSetting('User_Import','false')
        return notificationDialog(LANGUAGE(30053))
        

    def openEditor(self, file='temp.xsp', media='video'):
        self.log('openEditor, file = %s, media = %s'%(file,media)) 
        return xbmc.executebuiltin("ActivateWindow(smartplaylisteditor,video)")
        # path='special://profile/playlists/%s/%s'%(media,file)
        # return xbmc.executebuiltin("ActivateWindow(10136,%s,%s)"%(path,media))


    def openPlugin(self,addonID):
        self.log('openPlugin, addonID = %s'%(addonID)) 
        return xbmc.executebuiltin('RunAddon(%s)'%addonID)


    def openSettings(self,addonID):
        self.log('openSettings, addonID = %s'%(addonID)) 
        return xbmcaddon.Addon(id=addonID).openSettings()


    def selectResource(self, type):
        self.log('selectResource, type = %s'%(type)) 
        notificationDialog('Coming Soon')
        return REAL_SETTINGS.openSettings()


    def buildPoolListitem(self, data):
        item, type = data
        return buildMenuListItem(item['name'],type,iconImage=item['logo'])

    
    def run(self): 
        param = self.sysARG[1]
        self.log('run, param = %s'%(param))
        if isBusy():
            notificationDialog(LANGUAGE(30029)%(ADDON_NAME))
            return REAL_SETTINGS.openSettings()
            
        if param == None:                     
            return REAL_SETTINGS.openSettings()
        elif  param.startswith('Select_Resource'):
            return self.selectResource(param.split('_')[2])
        elif  param == 'Clear_Import':
            self.clearImport()
        elif  param == 'Clear_Predefined':
            self.clearPredefined()
        elif  param == 'Clear_Userdefined':
            self.clearUserChannels()
        elif  param == 'Clear_BlackList':
            self.clearBlackList()
        elif  param == 'User_Groups':
            self.userGroups()
        elif  param == 'Open_Editor':
            return self.openEditor()
        elif  param.startswith('Open_Settings'): 
            return self.openSettings(param.split('|')[1])
        elif  param.startswith('Open_Plugin'):   
            return self.openPlugin(param.split('|')[1])
        else: self.selectPredefined(param.replace('_',' '))
        return REAL_SETTINGS.openSettings()
            
if __name__ == '__main__': Config(sys.argv).run()