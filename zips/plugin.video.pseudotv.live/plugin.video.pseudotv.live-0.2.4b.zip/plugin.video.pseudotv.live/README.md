![](https://raw.githubusercontent.com/PseudoTV/PseudoTV_Artwork/master/PseudoTV%20Live/Flat/PTVL%20-%20Metro%20-%20Fanart%20(1).png)

## PseudoTV Live:

PseudoTV Live acts similar to normal broadcast or cable TV, complete with multiple preset, user-defined channels and advanced channel management.

PseudoTV Live can integrate with all Kodi sources including various Kodi plugins ie. Plex, Netflix, etc.
Create rich, in-depth channels with the added feature to import existing M3U/XMLTV pairs.

[Forum](https://forum.kodi.tv/showthread.php?tid=355549)


[Discussion](https://forum.kodi.tv/showthread.php?tid=346803)


[Channel Configuration Example](https://rawhttps://github.com/PseudoTV/PseudoTV_Live/raw/master/plugin.video.pseudotv.live/channels.json.githubusercontent.com/PseudoTV/PseudoTV_Live/master/channels.json)