#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from collections import deque
from pool import DaemonThreadPoolExecutor
from typing import Any, Optional

from variables    import *
from channels   import Channels
from xmltvs     import XMLTVS
from xsp        import XSP
from m3u        import M3U
from fillers    import Fillers
from resources  import Resources
from seasonal   import Seasonal 
from rules      import RulesList


def _shouldProbe(item: Any, accurate: bool, vfs: tuple) -> bool:
    """True when the item's duration probe may run in a worker thread.

    Pure-I/O probes are safe to parallelize. vfs-prefixed paths (plugin://, pvr://,
    resource://) resolve through xbmc.executeJSONRPC, which is not thread-safe, and
    'stack://' paths — both stay on the serial path. Items carrying duration/runtime
    metadata skip the probe unless accurate forces a re-probe."""
    if not isinstance(item, dict): return False
    if item.get('filetype') == 'directory': return False
    fle = item.get('file', '') or ''
    if not fle or fle.startswith('stack://') or fle.lower().startswith(vfs): return False
    if (item.get('duration') or item.get('runtime') or 0) > 0 and not accurate: return False
    return True


class Builder(object):
    xsp      = XSP()
    seasonal = Seasonal()
    loopback = None
    
    def __init__(self, service: Any):
        # Global dialog properties
        self.fCount    = 0
        self.pCount    = 0
        self.cCount    = 0
        self._buildIdx = 0
        self.pDialog   = None
        self.pMSG      = ''
        self.pName     = ''
        self.pHeader   = ''
        self.pErrors   = []
        
        # Global rules setup
        self.accurateDuration = bool(Globals.settings.getSettingInt('Duration_Type'))
        self.interleaveSet    = Globals.settings.getSettingInt('Interleave_Set')
        self.interleaveRepeat = Globals.settings.getSettingBool('Interleave_Repeat')
        self.incStrms         = Globals.settings.getSettingBool('Enable_Strms')
        self.inc3D            = Globals.settings.getSettingBool('Enable_3D')
        self.incExtras        = Globals.settings.getSettingBool('Enable_Extras') 
        self.incStrmDetails   = Globals.settings.getSettingBool('Enable_Details')
        self.enableBCTs       = Globals.settings.getSettingBool('Enable_Fillers')
        self.saveDuration     = Globals.settings.getSettingBool('Store_Duration')
        self.minDuration      = Globals.settings.getSettingInt('Seek_Tolerance')
        self.limit            = Globals.settings.getSettingInt('Page_Limit')
        self.recursiveLimit   = Globals.settings.getSettingInt('Recursive_Depth')
        self.padScheduling    = False #TODO Adv. Rules 
        self.padFilelist      = True # pad content-poor channels up to Page_Limit (automatic padding when available media < page limit)
        self.enableEven       = bool(Globals.settings.getSettingInt('Enable_Even'))
        self.evenEpisode      = Globals.settings.getSettingBool('Enable_Even_Force_Episode')
        self.evenShuffle      = Globals.settings.getSettingBool('Enable_Even_Force_Random')
        self.enableChanged    = Globals.settings.getSettingBool('Enable_Changed')
        
        self.filter           = {}
        self.sort             = {}
        self.limits           = {"end": -1, "start": 0, "total": 0}
        self.query            = {}
        
        # Pre-cache constant configuration lookups to minimize setting poll overhead
        preroll_max = Globals.settings.getSettingInt('Enable_Preroll')
        postroll_min = Globals.settings.getSettingInt('Enable_Postroll')
        post_chance = Globals.settings.getSettingInt('Random_Post_Chance')
        include_trailers = Globals.settings.getSettingBool('Include_Trailers_KODI')

        self.bctTypes = {
            "bumpers": {
                "min": -1, "max": preroll_max, "auto": preroll_max == -1, "enabled": bool(preroll_max), 
                "chance": Globals.settings.getSettingInt('Random_Pre_Chance'),
                "sources": {"ids": Globals.settings.getSetting('Resource_Bumpers').split('|'), "paths": [os.path.join(FILLER_LOC, 'Bumpers', '')]}, "items": {}
            },
            "ratings": {
                "min": -1, "max": preroll_max, "auto": preroll_max == -1, "enabled": bool(preroll_max), 
                "chance": Globals.settings.getSettingInt('Random_Pre_Chance'),
                "sources": {"ids": Globals.settings.getSetting('Resource_Ratings').split('|'), "paths": [os.path.join(FILLER_LOC, 'Ratings', '')]}, "items": {}
            },
            "adverts": {
                "min": postroll_min, "max": self.limit, "auto": postroll_min == -1, "enabled": bool(postroll_min), 
                "chance": post_chance,
                "sources": {"ids": Globals.settings.getSetting('Resource_Adverts').split('|'), "paths": [os.path.join(FILLER_LOC, 'Adverts', '')]}, "items": {}, "incKODI": include_trailers
            },
            "trailers": {
                "min": postroll_min, "max": self.limit, "auto": postroll_min == -1, "enabled": bool(postroll_min), 
                "chance": post_chance,
                "sources": {"ids": Globals.settings.getSetting('Resource_Trailers').split('|'), "paths": [os.path.join(FILLER_LOC, 'Trailers', '')]}, "items": {}, "incKODI": include_trailers
            },
            "extras": {
                "min": postroll_min, "max": self.limit, "auto": postroll_min == -1, "enabled": bool(postroll_min), 
                "chance": post_chance,
                "sources": {"ids": [], "paths": []}, "items": {}, "incKODI": Globals.settings.getSettingBool('Include_Extras_KODI')
            }
        }
        self.service   = service
        self.monitor   = service.monitor
        self.jsonRPC   = service.jsonRPC
        self.cache     = service.cache
        # Shared probe pool across Builder instances — prevents thread stacking
        # during rapid re-queuing on SOC systems.
        if not hasattr(Builder, '_shared_probe_pool') or Builder._shared_probe_pool is None:
            Builder._shared_probe_pool = DaemonThreadPoolExecutor(max_workers=min(8, CPU_COUNT))
        self._probe_pool = Builder._shared_probe_pool
        self.holiday   = self.seasonal.getHoliday()
        self.channels  = Channels(Globals.getChannelKey(), writable=True)
        self.resources = Resources(service)
        self.runActions = RulesList(self.channels.getChannels()).runActions


    def log(self, msg: str, level: int = xbmc.LOGDEBUG):
        LOG(f"{self.__class__.__name__}: {msg}", level)

    def probeTrailers(self, items: list) -> None:
        """Parallelize YouTube trailer duration probes on _probe_pool.

        Side-effect only: warms the duration cache so the serial addTrailer path
        doesn't pay ~3s per YouTube probe. Results are deliberately discarded, so
        futures are collected positionally — keying them by item raised
        "unhashable type: 'dict'" and aborted the whole pre-probe, forcing every
        trailer back onto the serial path.
        """
        futures = [self._probe_pool.submit(self.jsonRPC.getDuration, item.get('trailer'), None, False, False)
                   for item in items if isinstance(item, dict) and item.get('trailer')]
        for f in futures:
            try: f.result(timeout=30)
            except Exception: pass

    def getVerifiedChannels(self, channels: Optional[list] = None) -> list:
        if channels is None: 
            channels = self.channels.getChannels()
        channels = sorted(self._verify(channels), key=itemgetter('number'))
        self.log(f"getVerifiedChannels, channels = {len(channels)}")
        return channels

 
    def _verify(self, channels: Optional[list] = None):
        if channels is None: 
            channels = self.channels.getChannels()
        for idx, citem in enumerate(channels):
            if not citem.get('name') or len(citem.get('path', [])) == 0 or not citem.get('number'):
                self.log(f"[{citem.get('id')}] SKIPPING - missing necessary channel meta\n{citem}", xbmc.LOGINFO)
                continue
            elif not citem.get('enable', True):
                self.log(f"[{citem.get('id')}] SKIPPING - disabled channel\n{citem}", xbmc.LOGINFO)
                continue
            else:
                if not citem.get('id'): 
                    citem['id'] = Globals._getChannelID(citem['name'], citem['path'], citem['number'], Globals.settings.getMYUUID())
                citem['logo'] = self.resources.getLogo(citem, fallback=citem.get('logo', LOGO), lookup=True)
                self.log(f"[{citem['id']}] VERIFIED - channel {citem['number']}: {citem['name']} changed = {citem.get('changed', False)}", xbmc.LOGINFO)
                yield self.runActions(RULES_ACTION_CHANNEL_CITEM, citem, Globals._cleanGroups(citem), inherited=self)
             
             
    def buildCells(self, citem: dict, duration: int = MIN_EPG_DURATION, type: str = 'video', entries: int = 3, info: Optional[dict] = None) -> list:
        if info is None: info = {}
        art = info.setdefault('art', {})
        art['poster'] = art.get('poster') or Globals._getThumb(info, opt=1)
        art['fanart'] = art.get('fanart') or Globals._getThumb(info)
        
        info.update({
            'label': (info.get('title') or citem['name']),
            'episodetitle': (info.get('episodetitle') or '|'.join(citem.get('group', []))),
            'plot': (info.get('plot') or LANGUAGE(32020)),
            'genre': (info.get('genre') or ['Undefined']),
            'file': (info.get('path') or info.get('file') or info.get('originalpath') or '|'.join(citem.get('path', []))),
            'art': (info.get('art') or {"thumb": LOGO, "poster": LOGO_POSTER, "fanart": LOGO_LANDSCAPE, "landscape": LOGO_LANDSCAPE, "logo": LOGO, "icon": LOGO}),
            'type': type,
            'duration': duration,
            'start': 0,
            'stop': 0
        })
        copy_info = info.copy
        return [copy_info() for _ in range(entries)]


    def buildChannels(self, channels: Optional[list] = None, preview: bool = False, silent: Optional[bool] = None, write: bool = True) -> Optional[dict]:
        if channels is None: channels = []
        if silent is None:   silent = not Globals.settings.showDialog(silent)
        if preview and write: write = False
        self.log('buildChannels, channels=%d, preview=%s, silent=%s, write=%s' % (len(channels), preview, silent, write))
        
        if Globals.properties.isRunning('Builder.buildChannels'): return
        with Globals.properties.legacy(), Globals.properties.chkRunning('Builder.buildChannels'):
            channels = self.getVerifiedChannels(channels)
            if not channels: return
            changes  = set()
            complete = set()
            
            # Schedule epochs are local: _getGMTstamp() == time.time(), paired with
            # _epochTime(ts, tz=False) to render local DTFORMAT. _getUTCstamp()
            # returns the UTC wall-clock (time.time()-offset); passed to _epochTime
            # (tz=False) it renders DTFORMAT 4h ahead (local != UTC), scheduling new
            # channels in the future with empty guides.
            now = float(Globals._getGMTstamp())
            fallback_epoch = float(Globals._roundTimeDown(now, offset=60))
            fallback_str = Globals._epochTime(fallback_epoch, tz=False).strftime(DTFORMAT)

            self.pDialog, self.pName, self.pHeader = None, '', ''
            self.pMSG    = f"{LANGUAGE(32144)}: {LANGUAGE(32212)}"
            self.pErrors = []
            self.pCount  = 0
            self.cCount  = len(channels)
            self.service.buildState = {'running': True, 'pct': 0, 'channel': '', 'built': 0, 'total': self.cCount}
            
            preview_results = {}
            updated = False
            with M3U(writable=write) as m3u, XMLTVS(writable=write, m3u=m3u) as epg:
                with Globals.dialog._progressDialog(self.pMSG, ADDON_NAME, silent=silent, background=not preview) as self.pDialog:
                    all_stop_times = dict(epg.loadStopTimes(channels, fallback=fallback_str))
                    has_programmes = dict(epg.hasProgrammes(channels))
                    for citem in channels:
                        if not has_programmes.get(citem.get('id'), False):
                            self.log(f"[{citem.get('id')}] buildChannels, no programmes for {citem.get('name','')}, placeholder skipped", xbmc.LOGDEBUG)
                    if self.enableBCTs:
                        self.log('buildChannels, pre-computing filler sources')
                        Fillers({}, self)
                    
                    build_start = time.time()
                    BUILD_BUDGET = 600  # 10 minute build budget — re-queues remaining channels

                    for idx, citem in enumerate(channels):
                        try:
                            # Build time budget: prevent runaway builds on low-power devices.
                            # Re-queue remaining channels to resume on the next cycle.
                            if idx > 0 and (time.time() - build_start) > BUILD_BUDGET:
                                self.log(f"buildChannels, budget exceeded after {int(time.time() - build_start)}s — re-queuing {len(channels)-idx} remaining channels")
                                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                                if hasattr(self.service,'_que'): self.service._que(self.service.tasks.chkChannels,3,0,0,*(channels[idx:],silent))
                                break

                            # Memory budget: the build is the host's biggest memory
                            # consumer. Re-queue before the device runs out of
                            # reclaimable RAM — the OOM killer takes Kodi down whole,
                            # a deferred channel only resumes next cycle.
                            if isMemPressure():
                                self.log(f"buildChannels, low memory — re-queuing {len(channels)-idx} remaining channels")
                                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                                if hasattr(self.service,'_que'): self.service._que(self.service.tasks.chkChannels,3,0,0,*(channels[idx:],silent))
                                break

                            self._buildIdx = idx
                            self.pHeader = ADDON_NAME
                            self.pName   = citem.get('name', '')
                            self.pCount  = int(idx * 100) // self.cCount
                            self.service.buildState.update({'pct': self.pCount, 'channel': citem.get('name', ''), 'logo': citem.get('logo', ''), 'built': idx + 1})
                        
                            self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{self.pName}", header=self.pHeader)
                            
                            if self.service.interrupt():
                                self.log(f"[{citem.get('id')}] buildChannels, _interrupt")
                                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                                if hasattr(self.service,'_que'): self.service._que(self.service.tasks.chkChannels,3,0,0,*(channels[idx:],silent))
                                break
                            elif self.service.suspend():
                                self.log(f"[{citem.get('id')}] buildChannels, _suspend")
                                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32145)}", header=self.pHeader)
                                if self.monitor.waitForAbort(0.5): break
                                continue
                                
                            citem = self.runActions(RULES_ACTION_CHANNEL_TEMP_CITEM, citem, citem, inherited=self)
                            raw_start = all_stop_times.get(citem.get('id'), fallback_epoch)
                        
                            if isinstance(raw_start, str):
                                    start_epoch = float(datetime.datetime.strptime(raw_start, DTFORMAT).timestamp())
                                    start_timestamp_str = raw_start
                            else:
                                    start_epoch = float(raw_start)
                                    start_timestamp_str = Globals._epochTime(start_epoch, tz=False).strftime(DTFORMAT)

                            # New seasonal holiday: when a different holiday becomes
                            # active, cut the previous holiday's guide back to today's
                            # start and rebuild from there, so the new holiday's meta
                            # stitches at its own beginning.
                            s_paths = citem.get('path', [])
                            if isinstance(s_paths, (str, bytes)): s_paths = [s_paths]
                            if s_paths == ['{Seasonal}'] and self.holiday and self.holiday.get('keyword'):
                                current_kw = self.holiday.get('keyword')
                                stored_kw = self._getSeasonalHoliday(citem.get('id'))
                                if stored_kw and stored_kw != current_kw:
                                    holiday_start = float(datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
                                    holiday_start_str = Globals._epochTime(holiday_start, tz=False).strftime(DTFORMAT)
                                    removed = epg.truncateProgrammes(citem.get('id'), holiday_start_str)
                                    self.log(f"[{citem.get('id')}] buildChannels, holiday changed {stored_kw} -> {current_kw}, truncated {removed} old programmes to {holiday_start_str}", xbmc.LOGINFO)
                                    self._resetPagination(citem)
                                    start_epoch = holiday_start
                                    start_timestamp_str = holiday_start_str
                                self._setSeasonalHoliday(citem.get('id'), current_kw)

                            # Rebuild only when the existing guide doesn't already cover
                            # the near-term horizon (Min_Days — same horizon chkPVRSync
                            # uses). Evaluated on the RAW last-stop: clamping before this
                            # check made `start_epoch <= fallback_epoch` always true, so
                            # every channel rebuilt on every cycle.
                            _update = start_epoch <= now + (MIN_GUIDEDAYS * 86400)
                            if not _update:
                                self.log(f"[{citem.get('id')}] buildChannels, guide sufficient, skipping ({start_timestamp_str})", xbmc.LOGDEBUG)

                            # Re-anchor to now only when the guide is stale (its last
                            # programme ended in the past, so it no longer covers now).
                            # Continuing from a future last-stop extends the existing
                            # timeline, preserving programme start times — clamping a
                            # valid future schedule back to now truncated it and
                            # re-anchored every programme, so the guide shifted between
                            # builds (Kodi's ingested EPG no longer matched playback).
                            if _update and start_epoch < fallback_epoch:
                                start_epoch = fallback_epoch
                                start_timestamp_str = Globals._epochTime(fallback_epoch, tz=False).strftime(DTFORMAT)
                                self.log(f"[{citem.get('id')}] buildChannels, stale guide re-anchored to {start_timestamp_str}", xbmc.LOGWARNING)

                            self.log(f"[{citem.get('id')}] Schedule delta audit -> Update Required: {_update} | Target End: {start_timestamp_str}")

                            # fileList must be defined even when the channel is
                            # skipped (guide sufficient) — the station-keep block
                            # below tests `not fileList`.
                            fileList = []

                            # Truncate-then-append: when rebuilding, drop any existing
                            # programmes that would overlap the new schedule (their
                            # stop is after the build start). The future-start clamp
                            # pulls start_epoch back to now for channels whose guide
                            # doesn't reach Min_Days, so appending without clearing
                            # would overlap the still-valid tail and produce duplicate
                            # guide rows (wrong playback target).
                            if _update and start_epoch > 0:
                                epg.truncateProgrammes(citem.get('id'),
                                                       Globals._epochTime(start_epoch, tz=False).strftime(DTFORMAT),
                                                       mode='stop')

                            _changed = citem.get('changed', False)
                            if not _changed and getattr(self, 'enableChanged', False):
                                paths = citem.get('path', [])
                                if isinstance(paths, (str, bytes)):
                                    paths = [paths]
                                valid_extensions = tuple(KODI_PLAYLISTS + BASIC_PLAYLISTS)
                                _changed = any(self._playlistChanged(citem, idx, f, valid_extensions)
                                               for idx, f in enumerate(paths) if isinstance(f, str))
                        
                            if _changed:
                                    self.log(f"[{citem.get('id')}] Playlist signature mutation caught; flushing target datasets.")
                                    self._resetPagination(citem)
                                    m3u.delStation(citem)
                                    epg.delBroadcast(citem)
                                    citem['changed'] = False
                                    changes.add(self.channels.addChannel(citem))
                                    # The old guide was wiped above — anchor the rebuild
                                    # to now, NOT the deleted guide's (now stale) last-stop.
                                    # Continuing from that future last-stop re-anchored the
                                    # channel into the future and left today's guide empty.
                                    start_epoch = fallback_epoch
                                    start_timestamp_str = fallback_str

                            if _update or _changed:                       
                                    self.pMSG = LANGUAGE(32236) if preview else (f"{LANGUAGE(30014)} {LANGUAGE(30108) if len(channels) else LANGUAGE(30223)}" if start_timestamp_str == fallback_str else f"{LANGUAGE(32022)} {LANGUAGE(30223)}")
                                    self.pHeader = f'{ADDON_NAME}, {self.pMSG}'

                            if (_update or _changed) and start_epoch > 0:
                                self.runActions(RULES_ACTION_CHANNEL_START, citem, inherited=self)
                                fileList = self.buildMusic(citem) if citem.get('radio', False) else self.buildVideo(citem)
                                
                                if fileList is None:
                                    self.log(f"[{citem.get('id')}] buildChannels, suspended, requeueing remaining")
                                    if hasattr(self.service,'_que'): self.service._que(self.service.tasks.chkChannels,3,0,0,*(channels[idx:],silent))
                                    break
                                elif isinstance(fileList, list) and fileList:
                                    total_dur = sum(item.get('duration', 0) for item in fileList if isinstance(item, dict))
                                    self.log(f"[{citem.get('id')}] buildChannels, assigning time slots to {len(fileList)} items, total duration = {total_dur}s ({total_dur // 3600}h {(total_dur % 3600) // 60}m)")
                                    # Pre-schedule hook: rules (e.g. Prime-Time Block) may
                                    # reorder the queue before start/stop are stamped.
                                    fileList = self.runActions(RULES_ACTION_CHANNEL_BUILD_TIME_PRE, citem, fileList, inherited=self) or fileList
                                    for s_idx, item in enumerate(fileList):
                                        duration = item.get('duration')
                                        if not duration: continue
                                        item["idx"] = s_idx
                                        item['start'] = start_epoch
                                        item['stop'] = start_epoch + duration
                                        start_epoch = item['stop']
                                    
                                    fileList = sorted(self.runActions(RULES_ACTION_CHANNEL_BUILD_TIME_POST, citem, fileList, inherited=self), key=itemgetter('start'))
                                    if not citem.get('radio', False): fileList = sorted(Fillers(citem, self).injectFillers(fileList), key=itemgetter('start'))
                                    if preview: preview_results[citem.get('id')] = fileList
                                    else:
                                        prog_added = any([epg.addProgram(citem.get('id'), epg.getProgramItem(citem, item)) for item in fileList])
                                        updated = updated or prog_added
                                        self.log(f"[{citem.get('id')}] buildChannels, epg.addProgram: {prog_added}, {len(fileList)} programmes added")
                                                    
                                elif not fileList:
                                    has_progs = has_programmes.get(citem.get('id'), False)
                                    updated = updated or has_progs
                                    self.log(f"[{citem.get('id')}] buildChannels, no programmes found (has_existing={has_progs})")
                                self.runActions(RULES_ACTION_CHANNEL_STOP, citem, inherited=self)
                            else:
                                has_progs = has_programmes.get(citem.get('id'), False)
                                updated = updated or has_progs
                        
                            if updated: 
                                sitem = m3u.getStationItem(citem)
                                station_added = any((m3u.addStation(sitem), epg.addChannel(sitem)))
                                if station_added and not fileList:
                                    self.log(f"[{citem.get('id')}] buildChannels, station added but no programmes, placeholder skipped", xbmc.LOGDEBUG)
                                if station_added: complete.add(citem.get('id'))
                                self.log(f"[{citem.get('id')}] buildChannels, station added to m3u/epg: {station_added}")
                                # Bump XMLTV version after each channel so the render
                                # cache is invalidated and pvr.iptvsimple picks up
                                # fresh data on its next poll (incremental EPG updates).
                                try:
                                    old_meta = Globals.settings.getCacheSetting(XMLTV_META_KEY) or {}
                                    Globals.settings.setCacheSetting(XMLTV_META_KEY, {'updated': time.time(), 'version': (old_meta.get('version', 0) or 0) + 1}, life=-1)
                                except Exception: pass
                            elif _update or _changed:
                                self._resetPagination(citem)
                                # Keep the station even when the rebuild produced no
                                # programmes: the served XMLTV injects a "No Guide Data
                                # - Check Back Later" placeholder so the channel remains
                                # visible in Kodi.
                                sitem = m3u.getStationItem(citem)
                                m3u.addStation(sitem)
                                epg.addChannel(sitem)
                                complete.add(citem.get('id'))
                                self.log(f"[{citem.get('id')}] buildChannels, no programmes after rebuild, keeping station for placeholder")
                        except Exception as e: 
                            self.log(f"Channel compiler faulted critically at index execution point: {str(e)}", xbmc.LOGERROR)

        # Ensure buildState.running is always reset, even on exception.
        # Otherwise the throttle stays in reduced-delay mode forever and
        # webpoint reports a build in progress indefinitely.
        try:
            # Ensure every local M3U station has an XMLTV entry: only channels from the
            # local channels.json matter; remote multiroom stations are excluded.
            epg_ids = {ch.get('id') for ch in epg.getChannels()}
            for citem in channels:
                if citem.get('id') not in epg_ids:
                    self.log(f"[{citem.get('id')}] buildChannels, missing XMLTV entry for {citem.get('name','')}, placeholder skipped", xbmc.LOGDEBUG)

            self.channels.setChannels()

            # Run chkPVRSync AFTER _save completes — sees updated channel_ids
            if updated:
                self.log(f"Channel compilation finished: {len(complete)} stations added, {len(changes)} channels updated, {len(preview_results)} previews", xbmc.LOGINFO)
                in_sync, findings = self.service.tasks.chkPVRSync()
                if not in_sync:
                    self.log("buildChannels, post-build sync check: PVR out of sync, triggering immediate refresh", xbmc.LOGDEBUG)
                    # Pass findings to chkPVRRefresh so it sees epg_expired/missing_epg
                    # rather than recomputing with empty defaults (which skipped rebuilds).
                    self.service.tasks.chkPVRRefresh(findings=findings)
                else:
                    self.log("buildChannels, post-build sync check: PVR in sync", xbmc.LOGDEBUG)
        finally:
            self.service.buildState.update({'running': False, 'pct': 100})
            self._probe_pool.shutdown(wait=False, cancel_futures=True)
            Builder._shared_probe_pool = None  # allow recreation on next build
        return preview_results if preview else None


    def buildMusic(self, citem: dict) -> list:
        self.log(f"[{citem['id']}] buildMusic, generating {MAX_GUIDEDAYS * 8} cells @ {MIN_EPG_DURATION}s each")
        return self.buildCells(
            citem, MIN_EPG_DURATION, 'music', (MAX_GUIDEDAYS * 8), 
            info={
                'genre': ["Music"],
                'art': {"thumb": citem.get('logo', LOGO), "poster": LOGO_POSTER, "fanart": LOGO_LANDSCAPE, "landscape": LOGO_LANDSCAPE, "logo": citem.get('logo', LOGO), "icon": citem.get('logo', LOGO)},
                'plot': LANGUAGE(32029).format(name=citem['name'])
            }
        )
        
        
    def _playlistChanged(self, citem: dict, idx: int, path: str, valid_extensions: tuple) -> bool:
        """True when a channel's playlist definition changed since the last build.

        File playlists (.xsp/.xml/.m3u/...) CRC their on-disk content. Inline DXSP
        channels (videodb://...?xsp={json}) have no file - the ?xsp= payload is the
        whole definition - so CRC that against a stable per-channel key instead.
        """
        if path.endswith(valid_extensions):
            return Globals.settings.getFileCRC(path)
        if self.xsp.isDXSP(path):
            return Globals.settings.getStringCRC('channelCRC.%s.%s' % (citem.get('id'), idx), path.split('?xsp=', 1)[-1])
        return False


    def buildVideo(self, citem: dict, validate: bool = False) -> Any:
        paths = citem.get('path', [])
        if isinstance(paths, (str, bytes)):
            paths = [paths]
        path_len = len(paths)

        tmp_citem = citem.copy()
        tmp_citem['rules'] = dict(citem.get('rules', {}))
        if paths == ["{Seasonal}"]:
            nrules = {600: {"values": {0: list(self.seasonal.buildSeasonal(self.holiday))}}}
            tmp_citem['rules'].update(nrules)
            self.log(f" [{citem.get('id')}] buildVideo: Seasonal Content, new rules = {nrules}")
            
        if self.enableEven and not tmp_citem.get('rules', {}).get(701):
            nrules = {701: {"values": {0: Globals.settings.getSettingInt('Enable_Even'), 1: self.evenEpisode, 2: self.evenShuffle}}}
            tmp_citem['rules'].update(nrules)
            self.log(f" [{citem.get('id')}] buildVideo: Even Show Distribution, new rules = {nrules}")
            
        citem = tmp_citem
        fileArray = self.runActions(RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE, citem, list(), inherited=self) 
        self.log(f"[{citem.get('id')}] buildVideo, channel pre fileArray items = {len(fileArray)}", xbmc.LOGINFO)
        
        has_valid_files = any(len(sublist) > 0 for sublist in fileArray if isinstance(sublist, list))
        if not has_valid_files: 
            for idx, base_path in enumerate(paths):
                if self.service.interrupt():
                    self.log(f"[{citem.get('id')}] buildVideo, _interrupt")
                    self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                    return None
                elif self.service.suspend():
                    self.log(f"[{citem.get('id')}] buildVideo, _suspend")
                    self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32145)}", header=self.pHeader)
                    if self.monitor.waitForAbort(0.5): return None
                    continue
                
                if path_len > 1: self.pName = f"{citem.get('name', '')} {idx + 1}/{path_len}"
                sub_paths = self.xsp.parseXSP(citem.get('id'), base_path, self.incExtras) if self.xsp.isXSP(base_path) else [base_path]
                if self.sort.get("method", "") == 'random':
                    self.log(f"[{citem.get('id')}] buildVideo, random shuffling [{idx}/{len(sub_paths)}]")
                    sub_paths = Globals._randomShuffle(sub_paths)               

                sub_path_len = len(sub_paths)
                for cnt, path in enumerate(sub_paths):
                    if sub_path_len > 1:
                        self.pName = f"{citem.get('name', '')} {idx + 1}/{path_len}\n{cnt + 1}/{sub_path_len}"
                        
                    self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message=f'{self.pName}', header=self.pHeader)
                    processed_path = self.runActions(RULES_ACTION_CHANNEL_BUILD_PATH, citem, path, inherited=self)
                    fileList = self.buildFileList(citem, processed_path, 'video', self.limit, self.sort, self.limits, self.query)
                    
                    if isinstance(fileList, list): 
                        fileArray.append(fileList)
                        if validate and len(fileList) > 0: 
                            break
                            
                    self.log(f"[{citem.get('id')}] buildVideo, validate = {validate}, fileList [{len(fileList)}/{sum(len(sublist) for sublist in fileArray if isinstance(sublist, list))}], path [{cnt}/{self.limit}]\n{path}")
                if validate and any(len(sublist) > 0 for sublist in fileArray if isinstance(sublist, list)):
                    break

        fileArray = self.runActions(RULES_ACTION_CHANNEL_BUILD_FILEARRAY_POST, citem, fileArray, inherited=self) 
        if isinstance(fileArray, list):
            fileArrayLen = len(fileArray)
            self.log(f"[{citem.get('id')}] buildVideo, channel post fileArray items = {fileArrayLen}", xbmc.LOGINFO)
            if not any(len(sublist) > 0 for sublist in fileArray if isinstance(sublist, list)):
                self.log(f"[{citem.get('id')}] buildVideo, channel fileArray In-Valid!", xbmc.LOGINFO)
                return False
                
            interleaved = Globals._interleave(fileArray, self.interleaveSet, self.interleaveRepeat)
            self.log(f"[{citem.get('id')}] buildVideo, interleaved {fileArrayLen} paths -> {len(interleaved)} items (set={self.interleaveSet}, repeat={self.interleaveRepeat})")
            fileList = self.runActions(RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE, citem, interleaved, inherited=self)
            self.log(f"[{citem.get('id')}] buildVideo, pre fileList items = {len(fileList)}", xbmc.LOGINFO)
            fileList = self.runActions(RULES_ACTION_CHANNEL_BUILD_FILELIST_POST, citem, fileList, inherited=self)
            self.log(f"[{citem.get('id')}] buildVideo, post fileList items = {len(fileList)}", xbmc.LOGINFO)
        else:
            fileList = fileArray if isinstance(fileArray, list) else []
        return self.runActions(RULES_ACTION_CHANNEL_BUILD_FILELIST_RETURN, citem, fileList, inherited=self)


    def buildFileList(self, citem: dict, path: str, media: str = 'video', page: Optional[int] = None, sort: Optional[dict] = None, limits: Optional[dict] = None, query: Optional[dict] = None) -> list:
        if page is None:   page   = Globals.settings.getSettingInt('Page_Limit')
        if sort is None:   sort   = {}
        if limits is None: limits = {"end": -1, "start": 0, "total": 0}
        if query is None:  query  = {}
        self.log(f"[{citem.get('id')}] buildFileList, path = {path}\nmedia = {media}, limit = {page}, sort = {sort}, page = {limits}")
        self.loopback = None

        if self.xsp.isDXSP(path):
            path = self.xsp.parseDXSP(citem.get('id'), path, self.filter, self.incExtras)
     
        fileList = []
        dirCount = -1
        dirList  = deque([{'file': path}])
        self.log(f"[{citem.get('id')}] buildFileList, path = {path}\nsort = {sort}, limits = {limits}, page = {page}")
        
        while not self.monitor.abortRequested():
            if self.service.interrupt():
                self.log(f"[{citem.get('id')}] buildFileList, _interrupt")
                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                return []
            
            elif self.service.suspend():
                self.log(f"[{citem.get('id')}] buildFileList, _suspend")
                self.pDialog = Globals.dialog._updateProgress(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32145)}", header=self.pHeader)
                if self.monitor.waitForAbort(0.5): return []
                continue
            
            elif len(dirList) == 0 or dirCount >= self.recursiveLimit:
                list_len = len(fileList)
                if self.padFilelist and 0 < list_len < page: 
                    self.log(f"[{citem.get('id')}] buildFileList, __padFileList processing")
                    multiplier = page // list_len
                    remainder  = page % list_len
                    # copy each item so the schedule loop can stamp unique start/stop per slot
                    paddedList = [dict(item) for _ in range(multiplier) for item in fileList]
                    if remainder > 0: paddedList.extend(dict(item) for item in fileList[:remainder])
                    self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message='Padding schedule...', header=self.pHeader)
                    fileList = paddedList
                    
                elif list_len < page and len(dirList) > dirCount: self.pErrors.append(LANGUAGE(32262))
                self.log(f"[{citem.get('id')}] buildFileList, no more folders to parse or recursive limit met.")
                break
                
            else:
                dirCount += 1
                folder   = dirList.popleft()
                current_path = folder.get('file')
                
                if folder.get("label"): 
                    self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message=f'Scanning {folder.get("label")}...', header=self.pHeader)
                
                remaining_needed = abs(page - len(fileList))
                subfileList, subdirList, limits, errors = self.buildList(citem, current_path, media, remaining_needed, sort, limits, folder, query)
                if sort.get("method", "") == 'random':
                    self.log(f"[{citem.get('id')}] buildFileList, depth [{dirCount}/{self.recursiveLimit}], random shuffling")
                    if isinstance(subdirList, list):  subdirList  = Globals._randomShuffle(subdirList)
                    if isinstance(subfileList, list): subfileList = Globals._randomShuffle(subfileList)
                    
                if isinstance(subfileList, list): 
                    fileList.extend(subfileList)
                    
                if isinstance(subdirList, list):  
                    dirList.extend(subdirList)
                self.log(f"[{citem.get('id')}] buildFileList, depth [{dirCount}/{self.recursiveLimit}], adding fileList [{len(fileList)}/{page}] remaining sub-directories [{len(dirList)}]\npath = {current_path}, limits = {limits}")
        total_dur = sum(item.get('duration', 0) for item in fileList if isinstance(item, dict))
        self.log(f"[{citem.get('id')}] buildFileList, returning [{len(fileList)}/{page}] files, depth [{dirCount}/{self.recursiveLimit}], total duration = {total_dur}s ({total_dur // 3600}h {(total_dur % 3600) // 60}m)")
        return fileList


    def buildList(self, citem: dict, path: str, media: str = 'video', page: Optional[int] = None, sort: Optional[dict] = None, limits: Optional[dict] = None, dirItem: Optional[dict] = None, query: Optional[dict] = None) -> tuple:
        if page is None:    page    = Globals.settings.getSettingInt('Page_Limit')
        if sort is None:    sort    = {}
        if limits is None:  limits  = {"end": -1, "start": 0, "total": 0}
        if dirItem is None: dirItem = {}
        if query is None:   query   = {}
        self.log(f"[{citem.get('id')}] buildList, media = {media}, path = {path}\npage = {page}, sort = {sort}, query = {query}, limits = {limits}\ndirItem = {dirItem}")
        
        nlimits = limits
        pre_items = self.runActions(RULES_ACTION_CHANNEL_REQUEST_FILELIST_PRE, citem, [], inherited=self)
        items, nlimits, errors = self.jsonRPC.requestList(citem, path, media, page, sort, self.filter, limits, query)
        if not items and pre_items: items = pre_items
        items = self.runActions(RULES_ACTION_CHANNEL_REQUEST_FILELIST_POST, citem, items, inherited=self)
        
        error_msg = errors.get('message') if isinstance(errors, dict) else None
        if error_msg:
            self.pErrors.append(error_msg)
            return [], [], nlimits, errors
            
        if not items:
            self.log(f"[{citem.get('id')}] buildList, no request items found using path = {path}")
            self.pErrors.append(LANGUAGE(32026))
            return [], [], nlimits, errors
            
        if items == self.loopback and limits != nlimits:
            self.log(f"[{citem.get('id')}] buildList, loopback detected using path = {path}")
            self.pErrors.append(LANGUAGE(32030))
            return [], [], nlimits, errors
            
        self.loopback = items
        fileList, dirList = self.buildFiles(citem, path, items, media, page, sort, limits, dirItem, query)
        if len(fileList) == 0 and isinstance(dirList, list):
            has_matching_dir = any(
                path == d or (isinstance(d, dict) and d.get('file') == path) 
                for d in dirList
            )
            if has_matching_dir:
                self.jsonRPC.autoPagination(citem.get('id'), path, query, limits)
                
        self.log(f"[{citem.get('id')}] buildList, returning fileList [{len(fileList)}], dirList [{len(dirList)}]")
        return fileList, dirList, nlimits, errors


    def buildFiles(self, citem: dict, path: str, items: Optional[list] = None, media: str = 'video', page: Optional[int] = None, sort: Optional[dict] = None, limits: Optional[dict] = None, dirItem: Optional[dict] = None, query: Optional[dict] = None) -> tuple:
        if items is None:   items   = []
        if page is None:    page    = Globals.settings.getSettingInt('Page_Limit')
        if sort is None:    sort    = {}
        if limits is None:  limits  = {"end": -1, "start": 0, "total": 0}
        if dirItem is None: dirItem = {}
        if query is None:   query   = {}
        fileList, dirList, seasoneplist = [], [], []
        items_len = len(items)
        vfs_tuple = tuple(VFS_TYPES) if 'VFS_TYPES' in globals() else ()
        tv_tuple  = tuple(TV_TYPES) if 'TV_TYPES' in globals() else ()
        
        holiday   = None
        holiday_values = citem.get('rules', {}).get(600, {}).get('values', {}).get(0, [])
        if holiday_values and isinstance(holiday_values, list):
            holiday = holiday_values[0].get('holiday') if isinstance(holiday_values[0], dict) else None

        default_type = query.get('key', 'files')
        sort_method = sort.get("method", "")
        # Pre-probe trailer durations in parallel to avoid ~3s serial YouTube
        # probes blocking the service thread during addTrailer queue processing.
        trailer_items = [item for item in items if isinstance(item, dict) and item.get('trailer')]
        if trailer_items:
            try: self.probeTrailers(trailer_items)
            except Exception as e: self.log(f"[{citem.get('id')}] buildFiles, trailer pre-probe failed: {e}", xbmc.LOGWARNING)
        # Parallelize only pure-I/O duration probes. vfs-prefixed paths (plugin://,
        # pvr://, resource://) resolve through xbmc.executeJSONRPC, which is not
        # thread-safe, so they and 'stack://' paths stay on the serial path. Items
        # carrying duration/runtime metadata skip the probe unless accurate. Uses a
        # dedicated pool to avoid JSON-RPC timeouts starving probe threads.
        probe_futures = {}
        _vfs = tuple(VFS_TYPES) if 'VFS_TYPES' in globals() else ()
        try:
            for idx, item in enumerate(items):
                if _shouldProbe(item, self.accurateDuration, _vfs):
                    probe_futures[idx] = self._probe_pool.submit(
                        self.jsonRPC.getDuration, item.get('file'), item,
                        self.accurateDuration, self.saveDuration)
        except Exception as e:
            self.log(f"[{citem.get('id')}] buildFiles, parallel probe setup failed: {e}", xbmc.LOGWARNING)
            probe_futures = {}
        for idx, item in enumerate(items):
            if not isinstance(item, dict): continue
            
            file = item.get('file', '')
            fileType = item.get('filetype', 'file')
            
            if items_len > 0:
                self.fCount = int(idx * 100) // items_len
                if self.cCount == 1:
                    self.pCount = max(0, min(self.fCount, 99))
                else:
                    # Blend channel progress with per-file progress within the channel
                    # e.g., channel 3/20 = 15%, file 5/10 = 50% → pCount = 15% + (50% * 5% range) = 17%
                    if self.cCount > 0:
                        channel_base = int(self._buildIdx * 100) // self.cCount
                        channel_range = max(1, 100 // self.cCount)
                        self.pCount = min(99, channel_base + int(self.fCount * channel_range // 100))
                    else:
                        self.pCount = min(99, self.fCount)

            if not item.get('type'): 
                item['type'] = default_type

            if self.service.interrupt() or self.service.suspend():
                self.log(f"[{citem.get('id')}] buildFiles, _interrupt/_suspend")
                self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message=f"{LANGUAGE(32144)}: {LANGUAGE(32213)}", header=self.pHeader)
                break

            if fileType == 'directory':
                dirList.append(item)
                continue
            elif fileType != 'file':
                continue

            suffix = f' {self.fCount}%'
            self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message=f'{self.pName}{suffix}', header=self.pHeader)

            if file.startswith('pvr://'):
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx}, PVR item => FileItem! file = {file}", xbmc.LOGINFO)
                item = Globals._decodePlot(item.get('plot', ''))
                file = item.get('file', '')

            if not file:
                self.pErrors.append(LANGUAGE(32031))
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx}, skipping missing playable file! path = {path}", xbmc.LOGINFO)
                continue

            if file.lower().endswith('strm') and not self.incStrms: 
                self.pErrors.append(f"{LANGUAGE(32027)} STRM")
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx}, skipping strm file! file = {file}", xbmc.LOGINFO)
                continue

            if not self.inc3D and self.is3D(item):
                item['is3D'] = True
                self.pErrors.append(f"{LANGUAGE(32027)} 3D")
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx} skipping 3D file! file = {file}", xbmc.LOGINFO)
                continue

            # Fetch Missing Stream Details Metadata (Kodi JSON-RPC bug workaround)
            if self.incStrmDetails and not file.startswith(vfs_tuple):
                if not item.get('streamdetails', {}).get('video', []):
                    item['streamdetails'] = self.jsonRPC.getStreamDetails(file, media)

            label = item.get("title") or item.get("label") or dirItem.get('label') or ''
            if not label:  
                self.pErrors.append(LANGUAGE(32018).format(type=LANGUAGE(30188)))
                continue
                
            # Normalize Metadata Schemas (TV Shows vs Movies)
            is_tv_show = item['type'].startswith(tv_tuple) or "showtitle" in item
            
            if is_tv_show:
                tvtitle = item.get("showtitle") or item.get("label") or dirItem.get('label') or ''
                try:
                    season  = int(item.get("season", 0))
                    episode = int(item.get("episode", 0))
                except (ValueError, TypeError):
                    season, episode = 0, 0
                    
                if not file.startswith(vfs_tuple) and not self.incExtras and (season == 0 or episode == 0):
                    self.pErrors.append(f"{LANGUAGE(32027)} Extras")
                    self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx} skipping extras! file = {file}", xbmc.LOGINFO)
                    continue

                label = tvtitle
                item["tvshowtitle"]  = tvtitle
                item["episodetitle"] = label
                item["episodelabel"] = f"{label} ({season}x{str(episode).zfill(2)})"
                item["showlabel"]    = f"{tvtitle} - {item['episodelabel']}" if item['episodelabel'] else tvtitle
            else:
                tagline = item.get("tagline", "")
                if not tagline:
                    premiered = item.get("premiered") or item.get("aired")
                    tagline = "Premiered %s" % premiered if premiered else ""
                item["episodetitle"] = tagline
                item["episodelabel"] = tagline
                item["showlabel"]    = f"{item.get('title', '')} - {tagline}" if tagline else item.get('title', '')
            
            # Duration Validation — use metadata duration if available, skip expensive video parser
            meta_dur = item.get('duration') or item.get('runtime') or 0  # runtime may be in minutes for library items
            # meta_dur = item.get('duration') or (item.get('runtime', 0) * 60) or 0  # normalize runtime to seconds
            if meta_dur > 0 and not self.accurateDuration:
                dur = meta_dur
            else:
                fut = probe_futures.pop(idx, None)
                if fut is not None:
                    try: dur = fut.result()
                    except Exception as e:
                        self.log(f"[{citem.get('id')}] buildFiles, parallel probe failed: {e}", xbmc.LOGWARNING)
                        dur = 0
                else:
                    dur = self.jsonRPC.getDuration(file, item, self.accurateDuration, self.saveDuration)
            if dur > self.minDuration:
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx} accepted: dur={dur}s, min={self.minDuration}s, file = {file}")
                self.pDialog = Globals.dialog._updateProgressThrottled(self.pDialog, self.pCount, message=f'{self.pName}{suffix}', header=self.pHeader)
                item.update({
                    'duration'    : dur,
                    'media'       : media,
                    'originalpath': path,
                    'friendly'    : Globals.properties.getFriendlyName(),
                    'remote'      : Globals.properties.getRemoteHost()
                })
                    
                if item.get("year", 0) == 1601: 
                    item['year'] = 0
                    
                spTitle, spYear = Globals._splitYear(label)
                item['label'] = spTitle
                    
                if item.get('year', 0) == 0 and spYear: 
                    item['year'] = spYear
                    
                raw_plot = item.get("plot") or item.get("plotoutline") or item.get("description") or LANGUAGE(32020)
                item['plot'] = raw_plot.strip()
                    
                if holiday:
                    tagline_str = f" - [I]{holiday['tagline']}[/I]" if holiday.get("tagline") else ""
                    item["plot"] = f"[B]{holiday.get('name', '')}[/B]{tagline_str}\n{item['plot']}"
                    
                item['art'] = item.get('art', {}) or dirItem.get('art', {})
                item['art']['icon'] = citem.get('logo', '')
                    
                if item.get('trailer') and hasattr(self.service,'_que'): 
                    self.service._que(self.jsonRPC.addTrailer, 3, 0, 0, item, defer_save=True)
                    
                if sort_method == 'episode' and (season + episode) > 0: 
                    seasoneplist.append((season, episode, item))
                else: 
                    fileList.append(item)
            else: 
                self.pErrors.append(LANGUAGE(32032))
                self.log(f"[{citem.get('id')}] buildFiles, IDX = {idx} skipping content: duration too low ({dur}/{self.minDuration}) file = {file}", xbmc.LOGINFO)
        
        if sort_method == 'episode':
            self.log(f"[{citem.get('id')}] buildFiles, sorting by episode")
            seasoneplist.sort(key=lambda seep: (seep[0], seep[1]))
            fileList.extend(seep[2] for seep in seasoneplist)
                
        elif sort_method == 'random':
            self.log(f"[{citem.get('id')}] buildFiles, random shuffling")
            dirList  = Globals._randomShuffle(dirList)
            fileList = Globals._randomShuffle(fileList)
            
        if hasattr(self.jsonRPC, 'flushTrailers'):
            self.jsonRPC.flushTrailers()
        total_dur = sum(item.get('duration', 0) for item in fileList if isinstance(item, dict))
        self.log(f"[{citem.get('id')}] buildFiles, returning [{len(fileList)}] files, [{len(dirList)}] dirs, total duration = {total_dur}s ({total_dur // 3600}h {(total_dur % 3600) // 60}m)")
        return fileList, dirList


    def is3D(self, item: dict) -> bool:
        if 'is3D' in item: return item['is3D']
        file = item.get('file') or ''
        if not item.get('streamdetails',{}).get('video',[]) and not file.startswith(tuple(VFS_TYPES)):
            item['streamdetails'] = self.jsonRPC.getStreamDetails(file, item.get('media','video'))
        details = item.get('streamdetails',{})
        if 'video' in details and details.get('video') != [] and len(details.get('video')) > 0:
            if len(details['video'][0]['stereomode'] or []) > 0: return True
        return False


    def _resetPagination(self, citem: Any) -> bool:
        if isinstance(citem, list): return any(self.jsonRPC.resetPagination(item) for item in citem)
        return any(self.jsonRPC.resetPagination(citem.get('id'), path) for path in citem.get('path',[]) if citem.get('id'))


    def _getSeasonalHoliday(self, ch_id: str) -> Optional[str]:
        """Return the holiday keyword a seasonal channel was last built with."""
        key = 'seasonal.holiday.%s' % ch_id
        return Globals.settings.getCacheSetting(key, FileAccess._getMD5(key))


    def _setSeasonalHoliday(self, ch_id: str, keyword: str):
        """Remember the holiday keyword a seasonal channel was built with."""
        key = 'seasonal.holiday.%s' % ch_id
        Globals.settings.setCacheSetting(key, keyword, FileAccess._getMD5(key),
                                         life=datetime.timedelta(days=30))
    