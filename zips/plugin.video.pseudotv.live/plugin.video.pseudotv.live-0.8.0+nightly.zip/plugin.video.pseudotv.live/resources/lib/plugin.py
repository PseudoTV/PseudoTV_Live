#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from variables           import *
from _services           import _Service
from rules               import RulesList
from infotagger.listitem import ListItemInfoTag
from typing              import Optional, Tuple

class Plugin(object):
    def __init__(self, mode: str = 'playlist', sysInfo: dict = {}):
        self.service = _Service()   
        self.pool    = self.service.pool
        self.jsonRPC = self.service.jsonRPC
        self.cache   = self.service.cache
        self.monitor = self.service.monitor
        self.player  = self.service.player
        self.sysInfo = sysInfo
        self.sysInfo['seek'] = (sysInfo.get('seek') or abs(int(sysInfo.get('start',-1)) - int(sysInfo.get('now',-1))) if int(sysInfo.get('start',-1)) > 0 else -1)
        self.sysInfo["progresspercentage"] = round((self.sysInfo["seek"]/int(self.sysInfo["duration"])) * 100, 2) if self.sysInfo['seek'] > 0 else -1 
        
        # Widgets don't include listitem meta, attempt to find matching meta with jsonrpc
        if not self.sysInfo.get('fitem'): 
            self._update()

        # keep vid mirroring the (possibly refreshed) fitem.file. When
        # pvr.iptvsimple left {catchup-id} unresolved the strip path blanked vid,
        # which broke downstream playback paths expecting a valid source.
        if not self.sysInfo.get('vid') or self.sysInfo.get('vid') in ('', '-1'):
            self.sysInfo['vid'] = self.sysInfo.get('fitem', {}).get('file', '-1')

        # pvr.iptvsimple sometimes leaves {utc}/{duration}/{utcend}
        # unresolved when its EPG for the channel isn't loaded yet — the stripped
        # URL then carries no start/stop, so seek stays -1 and "current" programmes
        # play from the beginning. Recover the timeline from the live broadcast.
        # Skip when _skipRecover is set (catchup retry path) — fitem is already
        # resolved and the XMLTV lookup would block the main thread too long.
        if self.sysInfo['seek'] < 0 and not self.sysInfo.get('_skipRecover'):
            self._recover()
            
        # isVOD: a programme airing now is the channel's live broadcast (seek
        # applies); a programme outside its own [start, stop) window — past or
        # future — is a one-off request and plays from the start. The window
        # drives the decision; path comparison (file != vid) misfired once vid
        # mirrored fitem.file (context menu, widgets, unresolved-catchup retry).
        fstart = Globals._epoch(self.sysInfo.get('fitem', {}).get('start', 0))
        fstop  = Globals._epoch(self.sysInfo.get('fitem', {}).get('stop', 0))
        in_window = fstart > 0 and fstop > 0 and fstart <= int(time.time()) < fstop
        self.sysInfo['isVOD']      = fstart > 0 and fstop > 0 and not in_window
        self.sysInfo['isSTRM']     = self.sysInfo.get('fitem').get('file','').endswith('.strm')
        self.sysInfo['isPlaylist'] = bool(Globals.settings.getSettingInt('Playback_Method'))
        # isPlaylist only applies to VOD/STRM content — not normal live channels.
        # Without this guard, the global Playback_Method setting forces every live
        # channel into playPlaylist(), showing a "Playlist" toast and playing via
        # Kodi's playlist player instead of the normal PVR live path.
        mode = 'playlist' if any((self.sysInfo['isVOD'],self.sysInfo['isSTRM'],self.sysInfo['isPlaylist'] and (self.sysInfo['isVOD'] or self.sysInfo['isSTRM']))) else sysInfo.get('mode')
        self.log(f'__init__, mode = {mode}, sysInfo = {self.sysInfo}')
        
        with Globals.builtin.busy_dialog():
            if   mode == 'live':                    self.playLive()
            elif mode == 'radio':                   self.playRadio()
            elif mode == 'resume':                  self.playPaused()
            elif mode in ['vod','dvr']:             self.playVOD()
            elif mode in ['playlist','broadcast']:  self.playPlaylist()
        
    def log(self, msg: str, level: int = xbmc.LOGDEBUG):
        LOG(f"{self.__class__.__name__}: {msg}", level)

    def _update(self):
        self.log('[%s] _update'%(self.sysInfo.get('chid')))
        if not self.service.player.isPlaying() and Globals.settings.getSettingBool('Debug_Enable'): Globals.dialog.notificationDialog('%s %s\n%s'%(LANGUAGE(32248),LANGUAGE(30223),LANGUAGE(32140)))
        with Globals.properties.suspendActivity():
            pvritem = self.jsonRPC.matchChannel(self.sysInfo.get('name'),self.sysInfo.get('chid'),self.sysInfo.get('radio',False),extend=False)
        if pvritem:
            self.sysInfo['fitem'] = Globals._decodePlot(pvritem.get('broadcastnow',{}).get('plot',''))
            self.sysInfo['nitem'] = Globals._decodePlot(pvritem.get('broadcastnext',[{}])[0].get('plot',''))
        else:
            self.log('[%s] _update, channel not found in PVR, may need refresh' % self.sysInfo.get('chid'), xbmc.LOGWARNING)
            Globals.dialog.notificationDialog(LANGUAGE(32000))
                
    def _quePlaylist(self, listitems: list, pltype: int = xbmc.PLAYLIST_VIDEO, shuffle: Optional[bool] = None) -> Optional[Tuple[xbmc.PlayList, xbmcgui.ListItem]]:
        def __add(listitem: xbmcgui.ListItem):
            if listitem is None:
                self.log('[%s] _quePlaylist, skipping None listitem' % (self.sysInfo.get('chid')), xbmc.LOGWARNING)
            elif listitem.getPath():
                playlist.add(listitem.getPath(),listitem,listitems.index(listitem))
                
        if listitems:
            self.sysInfo['isPlaylist'] = True
            if shuffle is None: shuffle = Globals.builtin.isPlaylistRandom()
            self.log('[%s] _quePlaylist, listitems = %s, shuffle = %s'%(self.sysInfo.get('chid'), len(listitems), shuffle))
            playlist = xbmc.PlayList(pltype)
            playlist.clear()
            xbmc.sleep(100)#give playlist.clear() enough time to clear queue.           
            poolit(__add)(listitems)
            self.log('[%s] _quePlaylist, Playlist size = %s, shuffle = %s'%(self.sysInfo.get('chid'), playlist.size(),shuffle))
            if shuffle: playlist.shuffle()
            else:       playlist.unshuffle()
            return playlist, next((li for li in listitems if li is not None), xbmcgui.ListItem())

    def _getPVRItems(self) -> list:
        def __findCurrent(items: list, byFile: bool = True, found: int = -1) -> list:
            for pos, nextitem in enumerate(items):
                fitem = Globals._decodePlot(nextitem.get('plot',{}))
                if byFile and self.sysInfo.get('fitem',{}).get('file').lower() == fitem.get('file','').lower(): found = pos
                elif not byFile and ntime >= Globals._strpTime(nextitem.get('starttime')) and ntime < Globals._strpTime(nextitem.get('endtime')) and self.sysInfo.get('chid') == fitem.get('citem',{}).get('id',str(random.random())): found = pos
                if found >= 0:
                    self.log('[%s] __buildPlaylist __findCurrent found match!'%(self.sysInfo.get('chid')))
                    items = items[found:]
                    break
                
            if len(items) > 0:
                if self.sysInfo.get('mode',False) == 'playlist':
                    # Offset start based on user configured tolerances. 
                    nowitem = items.pop(0)
                    # content almost concluded, move to next queued item
                    if round(nowitem['progresspercentage']) > Globals.settings.getSettingInt('Seek_Threshold'):
                        self.log('[%s] __buildPlaylist, __findCurrent progress past threshold advance to nextitem'%(self.sysInfo.get('chid')))
                        nowitem = items.pop(0)
                    # content just started, reset seek and progress to the beginning. 
                    if round(nowitem['progress']) < Globals.settings.getSettingInt('Seek_Tolerance'):
                        self.log('[%s] __buildPlaylist, __findCurrent progress start at the beginning'%(self.sysInfo.get('chid')))
                        nowitem['progress']           = 0
                        nowitem['progresspercentage'] = 0
                    with Globals.properties.suspendActivity():
                        self.sysInfo['callback'] = self.jsonRPC.getCallback(self.sysInfo)
                    items = items[:Globals.settings.getSettingInt('Page_Limit')]# list of upcoming items, truncate for speed
                    items.insert(0,nowitem)
                Globals._combineDicts(self.sysInfo['fitem'],items[0].get('fitem',{}))
            self.log('[%s] __buildPlaylist, __findCurrent building nextitems (%s)'%(self.sysInfo.get('chid'),len(items)))
            return items
            
        self.log('[%s] _getPVRItems'%(self.sysInfo.get('chid')))
        with Globals.properties.suspendActivity():
            pvritem = self.jsonRPC.matchChannel(self.sysInfo.get('name'),self.sysInfo.get('chid'),self.sysInfo.get('radio',False),extend=True)
        
        if pvritem:
            pastItems = pvritem.get('broadcastpast',[]) # past items
            nowitem   = pvritem.get('broadcastnow',{})  # current item
            nextitems = pvritem.get('broadcastnext',[]) # future items
            nextitems.insert(0,nowitem)
            nextitems = pastItems + nextitems
            # start array at correct position
            if   self.sysInfo['fitem'].get('file'): nextitems = __findCurrent(nextitems)
            else:                                   nextitems = __findCurrent(nextitems, byFile=False)
            if len(nextitems) > 0: return nextitems
            else: Globals.dialog.notificationDialog(LANGUAGE(32164))
        else: Globals.dialog.notificationDialog(LANGUAGE(32000))
        return []
                   
    def _recover(self):
        """Recover start/stop/duration for live seek when the invoked URL carried
        unresolved {utc}/{duration}/{utcend} placeholders.

        pvr.iptvsimple resolves those tokens only when its EPG for the channel is
        loaded; on a cold start it invokes with the raw placeholders. default.py
        strips them (fixing mode='live'), which leaves sysInfo without a timeline
        so Plugin.__init__ computes seek=-1 and playback starts at 0:00. This
        recovers the timeline so _setResume can seek to the in-progress position.

        Sources, in order:
          1. fitem['start']/['stop'] — the ListItem Kodi passes often carries the
             current programme's epoch times (buildDictListItem reads 'start'/'stop'
             properties). Same epoch base as the URL 'now'.
          2. XMLTV — fallback when the ListItem lacks times.
        """
        try:
            self.log('[%s] _recover, seeking timeline' % self.sysInfo.get('chid'))
            now = int(self.sysInfo.get('now', 0)) or int(time.time())

            def _apply(start_epoch, stop_epoch):
                duration = max(1, stop_epoch - start_epoch)
                self.sysInfo['start']    = start_epoch
                self.sysInfo['stop']     = stop_epoch
                self.sysInfo['duration'] = duration
                self.sysInfo['seek']     = max(0, now - start_epoch)
                self.sysInfo['progresspercentage'] = round((self.sysInfo['seek'] / duration) * 100, 2)
                self.log('[%s] _recover, start=%s stop=%s duration=%s seek=%s' % (
                    self.sysInfo.get('chid'), start_epoch, stop_epoch, duration, self.sysInfo['seek']))

            # 1. fitem start/stop (epoch or DTFORMAT, from ListItem properties)
            fstart = Globals._epoch(self.sysInfo.get('fitem', {}).get('start', 0))
            fstop  = Globals._epoch(self.sysInfo.get('fitem', {}).get('stop', 0))
            if fstart > 0 and fstop > 0:
                if fstart <= now < fstop:
                    _apply(fstart, fstop)
                    return
                # selected programme has its own window (past/future) — don't
                # borrow the live broadcast's timeline, it poisons seek
                return

            # 2. XMLTV (UTC DTFORMAT strings)
            now_str = Globals._epochTime(now, tz=False).strftime(DTFORMAT)
            chid = self.sysInfo.get('chid')
            from xmltvs import XMLTVS
            with Globals.properties.suspendActivity():
                programmes = XMLTVS().getProgrammes()
            for prog in programmes:
                if prog.get('channel') != chid:
                    continue
                start, stop = prog.get('start', ''), prog.get('stop', '')
                if start and stop and start <= now_str < stop:
                    _apply(int(Globals._strpTime(start, DTFORMAT).timestamp()),
                           int(Globals._strpTime(stop, DTFORMAT).timestamp()))
                    return
            self.log('[%s] _recover, no timeline covers now=%s, seek disabled' % (chid, now_str))
        except Exception as e:
            self.log('[%s] _recover, failed: %s' % (self.sysInfo.get('chid'), e), xbmc.LOGDEBUG)

    def _setResume(self, listitem: xbmcgui.ListItem) -> xbmcgui.ListItem:
        seek = int(self.sysInfo.get('seek', 0) or 0)
        duration = int(self.sysInfo.get('duration', 0) or 0)
        # Near the end: seek deep into large network files causes audio sync
        # errors and player instability. Shares Seek_Threshold with the playlist
        # advance check (default 98, min 85, 100 disables) — a hardcoded 0.8
        # fired below the slider's own minimum and zeroed valid EPG offsets.
        threshold = Globals.settings.getSettingInt('Seek_Threshold')
        if duration > 0 and 0 < threshold < 100 and seek > (duration * threshold / 100.0):
            self.log('[%s] _setResume, seek %.0fs past %d%% of duration %ds — resetting to start' % (self.sysInfo.get('chid'), seek, threshold, duration))
            seek = 0
            self.sysInfo['seek'] = 0
            self.sysInfo['progresspercentage'] = 0
        if seek > Globals.settings.getSettingInt('Seek_Tolerance') and self.sysInfo.get('progresspercentage',100) < 100:
            self.log('[%s] _setResume, seek = %s, progresspercentage = %s\npath = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('seek',0), self.sysInfo.get('progresspercentage',100), listitem.getPath()))
            listitem.setProperty('startoffset', str(self.sysInfo['seek'])) #secs
            infoTag = ListItemInfoTag(listitem,'video')
            infoTag.set_resume_point({'ResumeTime':self.sysInfo['seek'],'TotalTime':duration})
        return listitem
        
    @threadit
    def playLive(self):
        self.log('[%s] playLive, name = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('name')))
        #VOD called from Guide not live! / break PVR bind for correct meta.
        if self.sysInfo['isVOD'] or self.sysInfo['isSTRM']:
            if self.sysInfo['isVOD']:
                self.sysInfo['mode'] = 'vod'
                self.sysInfo["seek"] = -1
                self.sysInfo["progresspercentage"] = -1
                self.sysInfo['name'] = self.sysInfo['fitem'].get('label')
                self.sysInfo['vid']  = self.sysInfo['fitem'].get('file')
                Globals.dialog.notificationDialog(f"{LANGUAGE(32185).format(name='Channel')}: [B]{self.sysInfo['fitem'].get('label')}[/B]\n{self.sysInfo['fitem'].get('episodelabel')}")
                listitem = Globals.listitems.buildItemListItem(self.sysInfo.get('fitem'))
            else:
                #STRM called from Guide, presumably live; workaround for Kodi bug w/strm handling in setResolvedUrl.
                listitem = self._setResume(Globals.listitems.buildItemListItem(self.sysInfo.get('fitem')))
            listitem.setProperty('sysInfo',FileAccess._encodeString(self.sysInfo))
            self._play(listitem.getPath(),listitem)
        else:#LIVE called from Guide/Channels.
            listitem = self._setResume(Globals.listitems.buildItemListItem(self.sysInfo.get('fitem')))
            listitem.setProperty('sysInfo',FileAccess._encodeString(self.sysInfo))
            self._resolveURL(True, listitem)
    
    @threadit
    def playRadio(self, limit: int = RADIO_ITEM_LIMIT):
        def __buildfItem(item: dict = {}) -> xbmcgui.ListItem:
            sysInfo = self.sysInfo.copy()
            sysInfo['isPlaylist'] = True
            listitem = Globals.listitems.buildItemListItem(item,'music')
            listitem.setProperty('sysInfo',FileAccess._encodeString(sysInfo))
            return listitem
            
        def __buildPlaylist(chid: str, name: str) -> list:
            with Globals.properties.suspendActivity():
                return Globals._randomShuffle(Globals._interleave([self.jsonRPC.requestList({'id':chid}, path, 'music', page=limit, sort={"method":"random"})[0] for path in self.sysInfo.get('vid').split('|')], Globals.settings.getSettingInt('Interleave_Set'), Globals.settings.getSettingBool('Interleave_Repeat')))
        
        self.log('[%s] playRadio, name = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('name')))
        listitems = poolit(__buildfItem)(__buildPlaylist(self.sysInfo.get('chid'),self.sysInfo.get('name')))
        self._play(*(self._quePlaylist(listitems, pltype=xbmc.PLAYLIST_MUSIC, shuffle=True)))
               
    @threadit         
    def playPaused(self):
        def __buildfItem(item: dict = {}) -> Optional[xbmcgui.ListItem]:
            sysInfo = self.sysInfo.copy()
            sysInfo['isPlaylist'] = True
            listitem = Globals.listitems.buildItemListItem(item,'video')
            if not FileAccess.exists(listitem.getPath()):
                # queue as-is, see playPlaylist.__buildfItem
                self.log('[%s] __buildfItem, missing media queued as-is: %s' % (self.sysInfo.get('chid'), listitem.getPath()), xbmc.LOGWARNING)
            elif item.get('file') == item.get('resume',{}).get('file',str(random.random())):
                seektime = int(item.get('resume',{}).get('position',0.0))
                runtime  = int(item.get('resume',{}).get('total',0.0))
                self.log('[%s] __buildfItem, within seek tolerance setting seek totaltime = %s, resumetime = %s'%(self.sysInfo.get('chid'), runtime, seektime))
                listitem.setProperty('startoffset', str(seektime)) #secs
                infoTag = ListItemInfoTag(listitem, 'video')
                infoTag.set_resume_point({'ResumeTime':seektime,'TotalTime':runtime * 60})
            sysInfo.update({'fitem':item,'resume':{"idx":0}}) # poolit map passes no index; rules default to 0
            listitem.setProperty('sysInfo',FileAccess._encodeString(sysInfo))
            return listitem
            
        def __buildPlaylist(chid: str, name: str) -> list:
            lizLST = RulesList([self.sysInfo.get('fitem',{}).get('citem',{'name':name,'id':chid})]).runActions(RULES_ACTION_PLAYBACK_RESUME, self.sysInfo.get('fitem',{}).get('citem',{'name':name,'id':chid}))
            if lizLST:
                lizLST = lizLST[:Globals.settings.getSettingInt('Page_Limit')]
                self.log('[%s] __buildPlaylist, building lizLST (%s)'%(chid, len(lizLST)))
                return poolit(__buildfItem)(lizLST)
            else: Globals.dialog.notificationDialog(LANGUAGE(32000))
            return []
        
        self.log('[%s] playPaused, name = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('name')))
        listitems = __buildPlaylist(self.sysInfo.get('chid'), self.sysInfo.get('name'))
        self._play(*(self._quePlaylist(listitems, pltype=xbmc.PLAYLIST_VIDEO, shuffle=False)))
            
    @threadit         
    def playVOD(self):
        self.log('[%s] playVOD, vid = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('vid')))
        self.sysInfo["seek"] = -1
        self.sysInfo["progresspercentage"] = -1
        Globals.dialog.notificationDialog(f"{LANGUAGE(32185).format(name='VOD')}: [B]{self.sysInfo['fitem'].get('label')}[/B]\n{self.sysInfo['fitem'].get('episodelabel')}")
        self._resolveURL(True, Globals.listitems.buildItemListItem(self.sysInfo.get('fitem')))
            
    @threadit
    def playPlaylist(self):
        def __buildfItem(nextitem: dict = {}) -> Optional[xbmcgui.ListItem]:
            sysInfo = self.sysInfo.copy()
            sysInfo['isPlaylist'] = True
            idx      = nextitems.index(nextitem)
            fitem    = Globals._decodePlot(nextitem.get('plot',''))
            listitem = Globals.listitems.buildItemListItem(fitem,'video')
            if not FileAccess.exists(listitem.getPath()):
                # Queue it anyway: a missing/failed stat (smb under load) must not
                # drop the entry - the player errors naturally on a real miss.
                # Returning None here landed in _quePlaylist.__add, killed the
                # executor loop, truncated the queue and stalled channel advance.
                self.log('[%s] __buildfItem, missing media queued as-is: %s' % (self.sysInfo.get('chid'), listitem.getPath()), xbmc.LOGWARNING)
            elif not self.sysInfo['isVOD']:
                listitem = self._setResume(Globals.listitems.buildItemListItem(self.sysInfo.get('fitem')))
            sysInfo.update({'fitem':fitem,'resume':{"idx":idx}})
            listitem.setProperty('sysInfo',FileAccess._encodeString(sysInfo))
            return listitem
            
        self.log('[%s] playPlaylist, name = %s'%(self.sysInfo.get('chid'), self.sysInfo.get('name')))
        Globals.dialog.notificationDialog(f"{LANGUAGE(32185).format(name='Playlist')}: [B]{self.sysInfo['name']}[/B]\n{self.sysInfo['fitem'].get('label')}")
        nextitems = self._getPVRItems()
        listitems = poolit(__buildfItem)(nextitems)
        self._play(*(self._quePlaylist(listitems, pltype=xbmc.PLAYLIST_VIDEO, shuffle=False)))
        
    def _playCheck(self, path: str, found: bool, listitem: Optional[xbmcgui.ListItem] = None) -> Tuple[str, bool, xbmcgui.ListItem]:
        def __findMissing(listitem: xbmcgui.ListItem) -> Tuple[bool, xbmcgui.ListItem]:
            label = (self.sysInfo['fitem'].get('label') or listitem.getLabel())
            file  = (self.sysInfo['fitem'].get('file')  or listitem.getPath())
            if file.startswith(tuple(VFS_TYPES)): found = True
            else:
                folder, filename  = os.path.split(file)
                oSeason, oEpisode = Globals._parseSE(filename)
                self.log(f"[{self.sysInfo.get('chid')}] _playCheck, __findMissing searching {label}: {filename} in {folder}")
                Globals.dialog.notificationDialog(f"Missing: [B]{self.sysInfo['fitem'].get('label')}[/B]\n{self.sysInfo['fitem'].get('episodelabel')}")
                with Globals.properties.suspendActivity():
                    items, limits, errors = self.jsonRPC.getDirectory({"directory":folder,"media": "video"})
                    
                found = False
                for item in items:
                    if item.get('file','').endswith(tuple(VIDEO_EXTS)):
                        season, episode  = Globals._parseSE(os.path.split(item.get('file',''))[1])
                        if item.get('type') == 'movies' and item.get('label','').lower() == label.lower():
                            found = True
                            break
                        elif oSeason and oEpisode and (oSeason == season and oEpisode == episode):
                            found = True
                            break
                if found: 
                    Globals._combineDicts(self.sysInfo['fitem'],item)
                    listitem.setPath(self.sysInfo['fitem']['file'])
                    self.log(f"[{self.sysInfo.get('chid')}] _playCheck, __findMissing found {self.sysInfo['fitem']['file']}")
                    Globals.dialog.notificationDialog(f"Found: [B]{self.sysInfo['fitem'].get('label')}[/B]\n{self.sysInfo['fitem'].get('episodelabel')}")
                #else: listitem.setPath(insert missing media placeholder)
            return found, listitem
            
        #File Exists
        if listitem is None: listitem = xbmcgui.ListItem()
        # Skip the existence stat for network shares (smb/nfs/dav). iptvsimple
        # already validated the live broadcast file, and a stat round-trip here
        # serializes behind _net_vfs_guard — stalling channel switches by ~50s while
        # a concurrent library scanner saturates the share. The player errors
        # naturally on a genuinely missing file.
        from fileaccess import isNetVFS
        if not isNetVFS(listitem.getPath()) and not FileAccess.exists(listitem.getPath()): found, listitem = __findMissing(listitem)
        #TODO ROBOUST ERROR CORRECTION
        if self.sysInfo['isPlaylist']: return path, found, listitem
        else:                          return listitem.getPath(), found, listitem

    def _play(self, file: str, listitem: Optional[xbmcgui.ListItem] = None, wait: int = 30):
        #PVR Live Channel Detection workaround.
        if listitem is None: listitem = xbmcgui.ListItem()
       
        while not self.monitor.abortRequested() and self.player.isPlaying():
            if    self.monitor.waitForAbort(0.5): return
            else: self.player.stop()
            
        file, found, listitem = self._playCheck(file, True, listitem)
        timerit(self.player.play)(1.0,*(file,listitem))
        self._resolveURL(False, listitem)
        #Playlist don't always gain screen focus depending on user Kodi configuration. Force fullscreen.
        self.log(f"[{self.sysInfo.get('chid')}] _play, found = {found}, playlist = {self.sysInfo['isPlaylist']}")
        
        while not self.monitor.abortRequested() and not self.player.isPlaying():
            if self.monitor.waitForAbort(0.5) or wait < 1: return
            wait -= 1
            
        if self.player.isPlayingAudio(): window = 'visualisation'
        else:                            window = 'fullscreenvideo'
        timerit(Globals.builtin.executewindow)(1.0,*('ActivateWindow(%s)'%(window),True,False,self.player.isPlaying))

    def _resolveURL(self, found: bool = False, listitem: Optional[xbmcgui.ListItem] = None):
        self.log(f"[{self.sysInfo.get('chid')}] _resolveURL, found = {found}: {listitem.getPath()}")
        if listitem is None: listitem = xbmcgui.ListItem()
        else: _, found, listitem = self._playCheck(listitem.getPath(), found, listitem)
        xbmcplugin.setResolvedUrl(int(self.sysInfo['sysARG'][1]), found, listitem)
        
        