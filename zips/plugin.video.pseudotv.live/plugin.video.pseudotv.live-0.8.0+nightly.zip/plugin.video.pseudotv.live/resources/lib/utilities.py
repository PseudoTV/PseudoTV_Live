#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from typing import Any, Optional, Tuple, List, Dict
from variables import *

class Utilities(object):
    
    @staticmethod
    def buildMenu(select: Optional[int] = None):        
        def __buildMenuItem(item: Dict[str, Any]):
            return Globals.listitems.buildMenuListItem(item.get('label'),item.get('label2'),item.get('icon'))
        
        items = [
                 {'label':LANGUAGE(32117)                  ,'label2':LANGUAGE(32120),'icon':ICON,'func':Utilities._runCleanup  , 'hide':False ,'args':(False,),'kwargs':{}}, #"Rebuild M3U/XMLTV/Genres"
                 {'label':LANGUAGE(32118)                  ,'label2':LANGUAGE(32119),'icon':ICON,'func':Utilities._runCleanup  , 'hide':False ,'args':(True,) ,'kwargs':{}}, #"Clean Start"
                 {'label':LANGUAGE(32121).format(name=PVR_CLIENT_NAME),'label2':LANGUAGE(32122),'icon':ICON,'func':Utilities._runReload   , 'hide':False ,'args':()      ,'kwargs':{}}, #"Force PVR reload"
                 {'label':LANGUAGE(32123)                  ,'label2':LANGUAGE(32124),'icon':ICON,'func':Utilities._runRestart  , 'hide':False ,'args':()      ,'kwargs':{}}, #"Force PTVL restart"
                 {'label':LANGUAGE(30205)                  ,'label2':LANGUAGE(30205),'icon':ICON,'func':Utilities._runCPUBench , 'hide':False ,'args':()      ,'kwargs':{}}, 
                 {'label':LANGUAGE(30208)                  ,'label2':LANGUAGE(30208),'icon':ICON,'func':Utilities._runIOBench  , 'hide':False ,'args':()      ,'kwargs':{}}, 
                 ]

        with Globals.builtin.busy_dialog():
            if not Globals.settings.getSettingBool('Debug_Enable'): items = [item for item in items if not item.get('hide',False)]
            listItems = poolit(__buildMenuItem)(sorted(items,key=itemgetter('label')))
            
        select = Globals.dialog.selectDialog(listItems, '%s - %s'%(ADDON_NAME,LANGUAGE(32126)),multi=False)
        if not select is None:
            try: 
                selectItem = [item for item in items if item.get('label') == listItems[select].getLabel()][0]
                LOG('Utilities: buildMenu, selectItem = %s'%selectItem)
                selectItem['func'](*selectItem.get('args',()),**selectItem.get('kwargs',{}))
            except Exception as e: 
                LOG('Utilities: buildMenu, failed! %s'%(e), xbmc.LOGERROR)
                return Globals.dialog.notificationDialog(LANGUAGE(32000))
        else: Globals._openSettings((6,1))
    
    
    @staticmethod
    def _runCleanup(full: bool = False):
        if Globals.dialog.yesnoDialog('Utilities: %s ?'%( LANGUAGE(32119) if full else LANGUAGE(32120) )): 
            with Globals.builtin.busy_dialog(lock=True), Globals.properties.interruptActivity():
                LOG('Utilities: _runCleanup, full %s'%(full))
                # M3U/XMLTV/genres now live in the SQLite cache — "cleaning" clears
                # the cache entries (and the in-memory XMLTV holder), not files.
                from m3u import clearM3UCache
                from xmltvs import clearXMLTVCache
                clearM3UCache()
                clearXMLTVCache()
                Globals.settings.clrCacheSetting(GENRES_CACHE_KEY)
                Globals.dialog.notificationDialog('%s: %s\n%s'%(LANGUAGE(32127),'M3U/XMLTV/Genres','cache'),silent=False)
                # Best-effort removal of any physical exports (Enable_File_Export)
                # so stale legacy files don't linger on disk.
                for path in (M3UFLEPATH, XMLTVFLEPATH, GENREFLEPATH):
                    try: FileAccess.delete(path)
                    except Exception: pass
                if full:
                    # Clean Start also resets user config + PVR instance (Kodi-managed files)
                    instanceName = Globals.properties.getFriendlyName()
                    for path in (SETTINGS_FLE, Globals.settings.instances.getPVRInstancePath(instanceName)):
                        try: FileAccess.delete(path)
                        except Exception: pass
                    Globals.settings.setCacheSetting('Utilities._runCleanup',Globals.settings.getCurrentSettings())
                    timerit(Globals.properties.setPendingRestart)(SERVICE_INTERVAL)
                Globals.dialog.notificationDialog(LANGUAGE(32025))

    
    @staticmethod
    def _runReload():
        if Globals.dialog.yesnoDialog('Utilities: %s?'%(LANGUAGE(32121).format(name=Globals.settings.getAddonDetails(PVR_CLIENT_ID).get('name')))):
            state = Globals.settings.getSettingBool('Enable_PVR_RELOAD')
            Globals.settings.setSettingBool('Enable_PVR_RELOAD',True)
            Globals.properties.setPropTimer('chkPVRRefresh')#refresh pvr guide
            timerit(Globals.settings.setSettingBool)(M3U_REFRESH,*('Enable_PVR_RELOAD',state))
        Globals.dialog.notificationDialog(LANGUAGE(32025))
            
    @staticmethod
    def _runRestart() -> bool:
        return Globals.properties.setPendingRestart()
        
    @staticmethod
    def _runCPUBench():
        with Globals.builtin.busy_dialog():
            if Globals.settings.hasAddon('script.pystone.benchmark', notify=True):
                return Globals.builtin.executebuiltin('RunScript(script.pystone.benchmark)')
        
    @staticmethod
    def _runIOBench():
        with Globals.builtin.busy_dialog():
            if Globals.settings.hasAddon('script.io.benchmark', notify=True):
                return Globals.builtin.executebuiltin('RunScript(script.io.benchmark,%s)'%(Globals._escapeString(f'path={CACHE_LOC}')))
    
    @staticmethod
    def qrWelcome():
        # New-user welcome: expanded first-run text + a QR to this box's web UI.
        # 34182 (not 32216) - qrWiki shares 32216 and needs its own shorter copy.
        manager = 'http://%s/manager.html'%(Globals.properties.getRemoteHost())
        Globals.dialog.qrDialog(manager, LANGUAGE(34182).format(name=ADDON_NAME,author=ADDON_AUTHOR))

    @staticmethod
    def qrWiki():
        Globals.dialog.qrDialog(URL_WIKI,LANGUAGE(32216).format(name=ADDON_NAME,author=ADDON_AUTHOR))

    @staticmethod
    def qrSupport():
        Globals.dialog.qrDialog(URL_SUPPORT, LANGUAGE(30033).format(name=ADDON_NAME))
        
    @staticmethod
    def qrRemote():
        Globals.dialog.qrDialog('Utilities: http://%s/%s'%(Globals.properties.getRemoteHost(),'remote.html'), LANGUAGE(30165))

    @staticmethod
    def qrReadme():
        Globals.dialog.qrDialog(URL_README, LANGUAGE(32043).format(name=ADDON_NAME,version=ADDON_VERSION))

    @staticmethod
    def qrBonjourDL():
        Globals.dialog.qrDialog(URL_WIN_BONJOUR, LANGUAGE(32217))
        
    @staticmethod
    def showChangeLOG():
        try:  
            def __addColor(text: str) -> str:
                text = text.replace('- Added'      ,'[COLOR=green][B]- Added:[/B][/COLOR]')
                text = text.replace('- Implemented','[COLOR=green][B]- Implemented:[/B][/COLOR]')
                text = text.replace('- Introduced' ,'[COLOR=green][B]- Introduced:[/B][/COLOR]')
                text = text.replace('- Addressed'  ,'[COLOR=green][B]- Addressed:[/B][/COLOR]')
                text = text.replace('- New!'       ,'[COLOR=yellow][B]- New!:[/B][/COLOR]')
                text = text.replace('- Optimized'  ,'[COLOR=yellow][B]- Optimized:[/B][/COLOR]')
                text = text.replace('- Improved'   ,'[COLOR=yellow][B]- Improved:[/B][/COLOR]')
                text = text.replace('- Modified'   ,'[COLOR=yellow][B]- Modified:[/B][/COLOR]')
                text = text.replace('- Enhanced'   ,'[COLOR=yellow][B]- Enhanced:[/B][/COLOR]')
                text = text.replace('- Fixed'      ,'[COLOR=yellow][B]- Fixed:[/B][/COLOR]')
                text = text.replace('- Refined'    ,'[COLOR=yellow][B]- Refined:[/B][/COLOR]')
                text = text.replace('- Overhauled' ,'[COLOR=yellow][B]- Overhauled:[/B][/COLOR]')
                text = text.replace('- Reworked'   ,'[COLOR=yellow][B]- Reworked:[/B][/COLOR]')
                text = text.replace('- Tweaked'    ,'[COLOR=yellow][B]- Tweaked:[/B][/COLOR]')
                text = text.replace('- Adjusted'   ,'[COLOR=yellow][B]- Adjusted:[/B][/COLOR]')
                text = text.replace('- Updated'    ,'[COLOR=yellow][B]- Updated:[/B][/COLOR]')
                text = text.replace('- Changed'    ,'[COLOR=yellow][B]- Changed:[/B][/COLOR]')
                text = text.replace('- Corrected'  ,'[COLOR=yellow][B]- Corrected:[/B][/COLOR]')
                text = text.replace('- Proper'     ,'[COLOR=yellow][B]- Proper:[/B][/COLOR]')
                text = text.replace('- Included'   ,'[COLOR=yellow][B]- Changed:[/B][/COLOR]')
                text = text.replace('- Notice'     ,'[COLOR=yellow][B]- Notice:[/B][/COLOR]')
                text = text.replace('- Refactored' ,'[COLOR=orange][B]- Refactored:[/B][/COLOR]')
                text = text.replace('- Resolved'   ,'[COLOR=orange][B]- Resolved:[/B][/COLOR]')
                text = text.replace('- Removed'    ,'[COLOR=red][B]- Removed:[/B][/COLOR]')
                text = text.replace('- Replaced'   ,'[COLOR=red][B]- Replaced:[/B][/COLOR]')
                text = text.replace('- Eliminated' ,'[COLOR=red][B]- Eliminated:[/B][/COLOR]')
                text = text.replace('- Excluded'   ,'[COLOR=red][B]- Excluded:[/B][/COLOR]')
                text = text.replace('- Deprecated' ,'[COLOR=red][B]- Deprecated:[/B][/COLOR]')
                text = text.replace('- Important'  ,'[COLOR=red][B]- Important:[/B][/COLOR]')
                text = text.replace('- Warning'    ,'[COLOR=red][B]- Warning:[/B][/COLOR]')
                return text  
                
            with Globals.builtin.busy_dialog():
                txt = ''
                # Prefer the online changelog (raw GitHub) via the shared HTTP
                # helper; fall back to the local bundled file when unreachable.
                try:
                    content = Globals.jsonRPC.requestURL(CHANGELOG_URL)
                    if isinstance(content, bytes):
                        content = content.decode(DEFAULT_ENCODING, 'replace')
                    if content: txt = content
                except Exception as e:
                    LOG('Utilities: showChangelog, URL fetch failed, using local file: %s'%(e), xbmc.LOGDEBUG)
                    txt = ''
                if not txt:
                    try:
                        with FileAccess.stream(CHANGELOG_FLE) as fle:
                            txt = fle.read()
                    except Exception as e:
                        LOG('Utilities: showChangelog, local file also failed: %s'%(e), xbmc.LOGWARNING)
                        txt = ''
                if not txt: raise Exception('no changelog available')
                Globals.dialog.textviewer(__addColor(txt), heading=(LANGUAGE(32045).format(name=ADDON_NAME,version=ADDON_VERSION)),usemono=True)
        except Exception as e: LOG('Utilities: showChangelog failed! %s'%(e), xbmc.LOGERROR)

    @staticmethod
    def qrDebug():
        def __cleanLog(content: str) -> str:           
            content = re.sub('//.+?:.+?@'                  ,'//USER:PASSWORD@'     , content)
            content = re.sub('<user>.+?</user>'            ,'<user>USER</user>'    , content)
            content = re.sub('<pass>.+?</pass>'            ,'<pass>PASSWORD</pass>', content)
            content = re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", '0.0.0.0'             , content)
            return content
                
        def __cleanPayload(payload: Dict[str, Any]) -> Dict[str, Any]:
            def __getDebug(payload: Dict[str, Any]) -> Dict[str, Any]: #only post errors
                debug = payload.get('debug',{})
                # [debug.pop(key) for key in list(debug.keys()) if key in ['LOGDEBUG','LOGINFO']]
                return debug
                    
            payload['debug']    = FileAccess.loadJSON(__cleanLog(FileAccess.dumpJSON(__getDebug(payload),idnt=4)), skip_cache=True)
            payload['channels'] = FileAccess.loadJSON(__cleanLog(FileAccess.dumpJSON(payload.get('channels',[]),idnt=4)), skip_cache=True)
            payload['m3u']      = FileAccess.loadJSON(__cleanLog(FileAccess.dumpJSON(payload.get('m3u',[]),idnt=4)), skip_cache=True)
            [payload.pop(key) for key in ['host','remotes','bonjour','library','servers'] if key in payload]
            return payload
        
        def __postLog(data: str) -> Tuple[bool, str]:
            try:
                session = requests.Session()
                response = session.post('https://paste.kodi.tv/' + 'documents', data=data.encode(DEFAULT_ENCODING), headers={'User-Agent':'%s: %s'%(ADDON_ID, ADDON_VERSION)})
                if 'key' in response.json():
                    return True, 'https://paste.kodi.tv/' + response.json()['key']
                elif 'message' in response.json():
                    LOG('Utilities: qrDebug, upload failed, paste may be too large')
                    return False, response.json()['message']
                else:
                    LOG('Utilities: qrDebug failed! %s'%response.text)
                    return False, LANGUAGE(30191)
            except Exception:
                LOG('Utilities: qrDebug, unable to retrieve the paste url')
                return False, LANGUAGE(30190)
              
        with Globals.builtin.busy_dialog():
            payload = Globals.settings.getPayload(inclDebug=True)
        if   not payload.get('debug',{}): return Globals.dialog.notificationDialog(LANGUAGE(32187))
        elif not Globals.dialog.yesnoDialog(message=LANGUAGE(32188)): return
        
        with Globals.builtin.busy_dialog():
            succes, data = __postLog(FileAccess.dumpJSON(__cleanPayload(payload),idnt=4))
            
        if succes: Globals.dialog.qrDialog(data,LANGUAGE(32189).format(url=data))
        else:      Globals.dialog.okDialog(LANGUAGE(32190).format(error=data))
       
    @staticmethod
    def _runLogger():
        with Globals.builtin.busy_dialog():
            if Globals.settings.hasAddon('script.kodi.loguploader', notify=True):
                return Globals.builtin.executebuiltin('RunScript(script.kodi.loguploader)')
        
    @staticmethod
    def _runUpdate(full: bool = False):
        LOG('Utilities: _runUpdate, full = %s'%(full))
        Globals.properties.setPropTimer('chkChannels')# Refresh Channel Changed!
              
    @staticmethod
    def openPositionUtil(idx: int):
        LOG('Utilities: openPositionUtil, idx = %s'%(idx))
        if not Globals.properties.isRunning('Utilities.openPositionUtil'):
            with Globals.properties.chkRunning('Utilities.openPositionUtil'):
                with Globals.builtin.busy_dialog():
                    from overlaytool import OverlayTool
                overlaytool = None # or `del` in finally raises UnboundLocalError, masking the original error
                try: overlaytool = OverlayTool(OVERLAYTOOL_XML, ADDON_PATH, "default", Focus_IDX=idx)
                except Exception as e: LOG("Utilities: openPositionUtil, failed! %s"%(e), xbmc.LOGERROR)
                finally: del overlaytool
                        
    @staticmethod
    def _migrateChannels(old: str = CACHE_LOC, new: str = BACKUP_LOC):
        """Migrate channel files from old location to new backup location.

        Lazy conversion path for legacy channel JSON into the current cached
        system: importChannels applies RULES_ID_MIGRATION so pre-0.2 rule ids
        are remapped to the execution-ordered scheme during the move."""
        old_path = os.path.join(old,CHANNELFLE)
        new_path = os.path.join(new,CHANNELFLE)
        if FileAccess.exists(old_path):
            self.log('migrate, importing %s...'%(old_path))
            if Backup().importChannels(old_path): Globals.properties.setPendingRestart(True)
            if FileAccess.move(old_path,new_path): Globals.dialog.notificationDialog(LANGUAGE(32025))
                  
         
# @threadit      
# def _clrLibrary():
    # #elif mode == 'clear_autotune' : _clrLibrary()
    # Globals.dialog.notificationDialog(LANGUAGE(32025))
    # manager = Manager(MANAGER_XML, ADDON_PATH, "default", start=False, channel=-1)
    # manager.clrLibraryCache()
    # del manager       
    
# @threadit   
# def _clrBlacklist():
    # # elif mode == 'clear_blackList': _clrBlacklist()
    # Globals.dialog.notificationDialog(LANGUAGE(32025))
    # Globals.settings.setSetting('Clear_BlackList','')
        
            
    @threadit
    def _run(self, sysARG: List[str]):
        with Globals.builtin.busy_dialog():
            ctl = (0,1)
            try:              param = sysARG[1]
            except Exception: param = None
            LOG('Utilities: param = %s'%(param))

            if param == 'Show_Menu':
                ctl = (6,0)  # misc -> Utility_MENU
                return self.buildMenu()
            elif param == 'Show_Welcome_QR':
                ctl = (6,1)  # misc -> Show_Welcome_QR
                return self.qrWelcome()
            elif param == 'Show_Wiki_QR':
                ctl = (6,4)  # misc -> Show_Wiki_QR
                return self.qrWiki()
            elif param == 'Show_Support_QR':
                ctl = (6,3)  # misc -> Show_Support_QR
                return self.qrSupport()
            elif param == 'Show_Remote_UI':
                ctl = (6,5)  # misc -> Show_Remote_UI
                return self.qrRemote()
            elif param == 'Show_Changelog':
                ctl = (6,2)  # misc -> Show_Changelog
                return self.showChangeLOG()
                
            #Globals
            if param.startswith('Move_Channelbug'):
                ctl = (2,14)  # globals -> Channel_Bug_Position_XY
                self.openPositionUtil(1)
            elif param.startswith('Move_OnNext'):
                ctl = (2,7)   # globals -> OnNext_Position_XY
                self.openPositionUtil(2)
                
            #Multi-Room
            elif param == 'Show_ZeroConf_QR':
                ctl = (4,9)  # sharing -> Show_ZeroConf_QR
                Utilities(sys.argv).qrBonjourDL()
                
            #Misc. Scripts
            elif param == 'CPU_Bench':
                self._runCPUBench()
            elif param == 'IO_Bench':
                self._runIOBench()
            elif param == 'Logger':
                self._runLogger()
                
            #Misc. Debug
            elif param == 'Debug_QR':
                ctl = (6,6)  # misc -> Debug_Enable
                return Utilities(sys.argv).qrDebug()
            return Globals._openSettings(ctl)

if __name__ == '__main__': Utilities()._run(sys.argv)