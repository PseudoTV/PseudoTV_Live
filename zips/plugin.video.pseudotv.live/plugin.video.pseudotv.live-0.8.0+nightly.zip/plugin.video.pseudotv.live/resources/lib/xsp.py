#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

from typing import Any, Optional
from variables import *
from library   import Library

_SHOW_YEAR_RE = re.compile(r'(.*) \((.*)\)', re.IGNORECASE)

class XSP(object):
    library = Library()
    
    def __init__(self):
        self.jsonRPC    = self.library.jsonRPC
        self.predefined = self.library.predefined


    def log(self, msg: str, level: int = xbmc.LOGDEBUG):
        LOG(f"{self.__class__.__name__}: {msg}", level)
    
    
    def isNode(self, path: str) -> bool:
        if path.lower().endswith('.xml'): return True
        return False
    


    def isXSP(self, path: str) -> bool:
        if path.lower().endswith('.xsp'): return True
        return False
        
    
    def isDXSP(self, path: str) -> bool:
        if 'db://' in path.lower() and '?xsp=' in path.lower(): return True
        return False
        
        
    def getName(self, fle: str) -> str:
        try:
            name = ''
            key  = 'name'
            if self.isNode(fle): key = 'label' #node not playlist
            fle = fle.strip('/').replace('library://','special://userdata/library/')
            with FileAccess.open(fle, "r") as xml:
                string = xml.read()
            match = re.compile(r'<%s>(.*?)\</%s>'%(key,key), re.IGNORECASE).search(string)
            if match: name = Globals._unescapeString(match.group(1))
            self.log("getName, fle = %s, name = %s"%(fle,name))
        except Exception: self.log("getName, return unable to parse %s"%(fle), xbmc.LOGERROR)
        return name


    def findXSP(self, name: str) -> str:
        self.log("findXSP, name = %s"%(name))
        playlists = self.library.getPlaylists()
        for item in playlists:
            if item.get('name','').lower() == name.lower():
                self.log("findXSP, found = %s"%(item.get('path')))
                return item.get('path')
        return ""
      


    def parseXSP(self, id: str, file: str, incExtras: Optional[bool] = None) -> list:
        def _createDXSP(tvshow: str, sort: Optional[dict] = None, operator: str = 'is') -> dict:
            if sort is None: sort = {'order':'ascending','method':'episode'}
            param = {"type":"episodes","rules":{"and":[],"or":[]},"order":{"direction":sort.get('order','ascending'),"method":sort.get('method','episode'),"ignorearticle":True,"useartistsortname":True}}
            try:
                match = _SHOW_YEAR_RE.search(tvshow)
                year, title = int(match.group(2)), match.group(1)
                param.setdefault("rules",{}).setdefault("and",[]).extend([{"field":"year","operator":f"{operator}","value":[year]},{"field":"tvshow","operator":"is","value":[Globals._quoteString(title)]}])
            except Exception:
                param.setdefault("rules",{}).setdefault("and",[]).append({"field":"tvshow","operator":f"{operator}","value":[Globals._quoteString(tvshow)]})
            return param
        def _parseOrder(dom) -> dict:
            # ponytail: shared <order> reader for both playlist types; empty attrs
            # are dropped so callers fall back to their own defaults.
            sort = {}
            try:    order = dom.getElementsByTagName("order")[0]
            except Exception: return sort # no <order> element
            try:    sort.update({'order':order.getAttribute("direction")})
            except Exception as e: self.log('parseXSP order direction failed: %s' % e, xbmc.LOGDEBUG)
            try:    sort.update({'method':order.firstChild.data})
            except Exception as e: self.log('parseXSP order method failed: %s' % e, xbmc.LOGDEBUG)
            return {k:v for k,v in sort.items() if v}
        if incExtras is None:
            incExtras = Globals.settings.getSettingBool('Enable_Extras')
        try: 
            xml = FileAccess.open(file, "r")
            dom = parse(xml)
            xml.close()
            
            try:    type = dom.getElementsByTagName('smartplaylist')[0].attributes['type'].value
            except Exception: type = MUSIC_TYPES[0]
            if type.lower() in map(str.lower,MUSIC_TYPES): return []
            else:
                if type.lower() == "tvshows":
                    sort = _parseOrder(dom)

                    paths = []
                    for rule in dom.getElementsByTagName("rule"):
                        if rule.getAttribute("field").lower() == "title" and rule.getAttribute("operator").lower() in ["is", "contains"]:
                            for value in rule.getElementsByTagName("value"):
                                if value.firstChild:
                                    paths.append('videodb://tvshows/titles/-1/-1/-1/?xsp=%s'%(FileAccess.dumpJSON(_createDXSP(value.firstChild.data, sort, rule.getAttribute("operator")))))
                    
                    if len(paths) == 0:   
                        items = self.jsonRPC.getDirectory({"directory":file,"media":"video"},True,ADDON_VERSION,datetime.timedelta(minutes=15))[0]
                        for item in items:
                            if item.get('filetype') == 'directory' and item.get('label'):
                                paths.append('videodb://tvshows/titles/-1/-1/-1/?xsp=%s'%(FileAccess.dumpJSON(_createDXSP(item.get('label'), sort))))
                    
                    self.log("[%s] parseXSP [%s], type = %s, sort = %s, paths = %s"%(id,file, type, sort, '\n'.join(paths)))
                    if len(paths) > 0: return paths

                elif type.lower() == "episodes":
                    # Episodes playlist (.xsp file): rebuild as an inline dynamic
                    # path so extras (season 0 / episode 0) are filtered at the
                    # JSONRPC layer instead of post-download. Bare .xsp paths hit
                    # Files.GetDirectory with no season/episode rule.
                    rules = {"and": []}
                    for rule in dom.getElementsByTagName("rule"):
                        try:
                            field    = rule.getAttribute("field")
                            operator = rule.getAttribute("operator")
                            values   = []
                            for value in rule.getElementsByTagName("value"):
                                if value.firstChild:
                                    values.append(Globals._unescapeString(value.firstChild.data))
                            if field and operator and values:
                                rules["and"].append({"field":field,"operator":operator,"value":values if len(values) > 1 else values[0]})
                        except Exception as e: self.log("[%s] parseXSP, rule parse failed: %s"%(id,e), xbmc.LOGDEBUG)

                    if not incExtras:
                        rules["and"].extend([{"field":"season" ,"operator":"greaterthan","value":"0"},
                                             {"field":"episode","operator":"greaterthan","value":"0"}])

                    sort = _parseOrder(dom)
                    params = {"type":"episodes","rules":rules,
                              "order":{"direction":sort.get('order','ascending'),"method":sort.get('method','episode'),"ignorearticle":True,"useartistsortname":True}}
                    out = 'videodb://tvshows/titles/-1/-1/-1/?xsp=%s'%(FileAccess.dumpJSON(params))
                    self.log("[%s] parseXSP [%s], type = episodes -> %s"%(id,file,out))
                    return [out]
        except Exception as e: self.log("[%s] parseXSP [%s], failed! %s"%(id,file,e), xbmc.LOGERROR)
        return [file]
            


    def parseDXSP(self, id: str, file: str, filters: Optional[dict] = None, incExtras: Optional[bool] = None) -> str:
        if filters is None:
            filters = {}
        if incExtras is None:
            incExtras = Globals.settings.getSettingBool('Enable_Extras')
        self.log("[%s] parseDXSP, IN = %s, filters = %s, incExtras = %s"%(id,file,filters,incExtras))
        try:
            path, params = str(file).split('?xsp=')
            if path.lower().startswith('musicdb://'):
                self.log("[%s] parseDXSP, found invalid music path! %s"%(id), xbmc.LOGINFO)
                return ''
        
            params = FileAccess.loadJSON(params, skip_cache=True)
            params['rules'].update(filters)
            if '-1/-1/-1/' not in path and 'recentlyadded' not in path.lower(): path = '%s/-1/-1/-1/'%(path.strip('/')) #flatten xsp
            if 'tvshows' in path:
                if not incExtras: #hide seasons and extras
                    # If rules is a single rule (has 'field'), wrap in 'and' first
                    if params['rules'].get("field") and not params['rules'].get("and"):
                        params['rules'] = {"and": [params['rules']]}
                    params['rules'].setdefault("and",[]).extend([{"field":"season" ,"operator":"greaterthan","value":"0"}, 
                                                                 {"field":"episode","operator":"greaterthan","value":"0"}])
                else:
                    params['rules']['and'] = [r for r in params['rules'].get("and", []) if not (('season' in r or 'episode' in r) and r.get("value") == "0")]
                    params['rules']['and'] = Globals._setDictLST(params['rules']['and'])
            file = '%s?xsp=%s'%(path,FileAccess.dumpJSON(params))
            self.log("[%s] parseDXSP, OUT = %s"%(id,file))
        except Exception as e: self.log("[%s] parseDXSP, failed! %s"%(id,e), xbmc.LOGERROR)
        return file
        
        