#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

from typing import Any, Generator, Optional, Union

from variables    import *
from multiroom  import Multiroom

#todo create dataclasses for all jsons
# https://pypi.org/project/dataclasses-json/
class Channels(object):
    _default_data = None   # memoized static default template (CHANNELFLE_DEFAULT)

    def __init__(self, key: str, writable: bool = False):
        self._lock       = RLock()
        self.writable    = writable
        if Channels._default_data is None:
            Channels._default_data = FileAccess.getJSON(CHANNELFLE_DEFAULT)
        # Deep-copy the memoized template per instance: _load()/pop(0)/update()
        # mutate this instance's structure and must never alias the shared copy.
        import copy
        self.channelDATA = copy.deepcopy(Channels._default_data)
        self.channelKEY  = f'{key}.{self.channelDATA.get("version","0.0.0")}'
        channels = self.channelDATA.get('channels') or []
        self.channelTEMP = channels.pop(0) if channels else {}
        self.channelRULE = self.channelTEMP.pop('rules', {})
        self.channelRULE.pop("0", None)
        self._isAutotune = (CHANNEL_KEY_AUTOTUNE in self.channelKEY)
        self.channelDATA.update(self._load())
        self.log(f'__init__ channelKEY = {self.channelKEY}, template keys = {len(self.channelTEMP)}')
        
        
    @property
    def isAutotune(self) -> bool:
        return self._isAutotune


    def __exit__(self, exc_type: Optional[type], exc_val: Optional[Exception], exc_tb: Optional[Any]):
        try:
            if self.writable: self._save()
        except Exception as e: self.log("__exit__ save failed: %s" % e, xbmc.LOGDEBUG)
            
    # No __del__ save: GC may collect a STALE instance (loaded before another
    # process committed newer data) and its deferred save would clobber the
    # fresher row — that exact race wiped the autotune/user channel keys.
    # Every mutator persists explicitly (setChannels/setImportPlugins/_save).
        
        
    def log(self, msg: str, level: int = xbmc.LOGDEBUG):
        LOG('%s: [%s] %s'%(self.__class__.__name__,self.channelKEY,msg),level)


    def _load(self) -> dict:
        channelDATA = Globals.settings.getCacheSetting(self.channelKEY, FileAccess._getMD5(self.channelKEY), default=self.channelDATA)
        # Not updating 'Open_Manager' here: this runs on every Channels() construction
        # (each HTTP M3U/XMLTV poll, rules load, etc.) and setSetting rewrites
        # settings.xml from disk each time. The display count is refreshed in
        # setChannels() (the write path) instead — a read must not write.
        self.log('_load, channels=%d' % len(channelDATA.get('channels',[])))
        return channelDATA
    
        
    def _verify(self, channels: list = []) -> Generator[dict, None, None]:
        """Filter and yield only valid channel items with required fields."""
        template_keys = {'catchup': '', 'changed': False, 'enable': True, 'favorite': False,
                         'group': [], 'id': '', 'logo': '', 'name': '', 'number': 0,
                         'path': [], 'radio': False, 'rules': {}, 'type': ''}
        for idx, citem in enumerate(channels):
            if not citem.get('name') or not citem.get('id') or len(citem.get('path',[])) == 0:
                self.log('[%s] _verify in-valid\n%s'%(citem.get('id'),citem))
                continue
            # Ensure all template keys are present with defaults
            for key, default in template_keys.items():
                if key not in citem:
                    citem[key] = default
            # Lazy rule-id migration: remap pre-0.2 myIds to the renumbered scheme.
            rules = citem.get('rules')
            if isinstance(rules, dict) and rules:
                citem['rules'] = {RULES_ID_MIGRATION.get(int(k), int(k)) if str(k).isdigit() else k: v
                                  for k, v in rules.items()}
            yield citem
                
                
    def _save(self, expiration=-1) -> bool:
        if self.writable:
            if self.isAutotune:
                expiration = datetime.timedelta(days=MAX_GUIDEDAYS)
                FileAccess.setJSON(CHANNEL_EXPORT_FLE,self.channelDATA)
            Globals.properties.notifyDataChanged('channels')
            self.log('_save, channels=%d, expiration=%s' % (len(self.channelDATA['channels']), expiration))
            return Globals.settings.setCacheSetting(self.channelKEY, self.channelDATA, FileAccess._getMD5(self.channelKEY), expiration)
            

    def getTemplate(self) -> dict: 
        return self.channelTEMP.copy()
        
        
    def getChannels(self) -> list:
        with self._lock:
            self.log('getChannels, channels=%d' % len(self.channelDATA.get('channels',[])))
            return sorted(self.channelDATA['channels'], key=itemgetter('number'))
        
        
    def getChannelbyID(self, id: str) -> list:
        return [c for c in self.channelDATA['channels'] if c.get('id') == id]
        
        
    def getChannelbyType(self, type: str) -> list:
        return [citem for citem in self.channelDATA['channels'] if citem.get('type') == type]


    def sortChannels(self, channels: list) -> list:
        try:              return sorted(channels, key=itemgetter('number'))
        except Exception as e: 
            self.log(f'sortChannels, failed to sort by number: {e}', xbmc.LOGDEBUG)
            return channels

    
    def setChannels(self, channels: Optional[list] = None) -> bool:
        with self._lock:
            if channels is None: channels = self.channelDATA['channels']
            self.channelDATA['name']     = Globals.properties.getFriendlyName()
            self.channelDATA['uuid']     = Globals.settings.getMYUUID()
            self.channelDATA['channels'] = self.sortChannels(list(self._verify(channels)))
            if len(self.channelDATA['channels']) > 0: Globals.properties.setHasChannels(self.channelKEY, self.channelDATA)
            Globals.settings.setSetting('Open_Manager','[B]%s[/B] Channels'%(len(self.channelDATA['channels'])))
            self.log('setChannels, channels=%d' % len(self.channelDATA.get('channels',[])))
        return self._save()
        
        
    def getImportPlugins(self) -> list:
        return self.channelDATA.get('plugins',[])
        
        
    def setImportPlugins(self, data: list=[]) -> bool:
        self.channelDATA['plugins'] = data
        return self._save()
         
         
    def clrChannels(self):
        self.channelDATA['channels'] = []
        

    def delChannel(self, citem: Optional[Union[dict, list]] = None) -> bool:
        """Delete channel(s) by ID or dict. Handles single dict or list of dicts."""
        if citem is None: citem = {}
        if isinstance(citem,list): return any(self.delChannel(channel) for channel in citem)
        with self._lock:
            try: 
                self.channelDATA['channels'].pop(self.findChannel(citem)[0])
                self.log('[%s] delChannel channel deleted!'%(citem['id']), xbmc.LOGINFO)
                return True
            except Exception as e: self.log('[%s] delChannel failed: %s'%(citem.get('id',''), e), xbmc.LOGDEBUG)
    
    
    def addChannel(self, citem: Union[dict, list] = {}) -> bool:
        """Add a channel or list of channels, removing duplicates first."""
        if isinstance(citem,list): return any(self.addChannel(channel) for channel in citem)
        with self._lock:
            self.delChannel(citem)
            self.log('[%s] addChannel adding channel %s'%(citem["id"],citem["name"]), xbmc.LOGINFO)
            self.channelDATA.setdefault('channels',[]).append(Globals._cleanGroups(citem))
            return True
        
        
    def findChannel(self, citem: dict = {}, channels: Optional[list] = None) -> tuple:
        """Find a channel by ID, returning (index, channel) tuple or (None, {}) if not found."""
        if channels is None: channels = self.channelDATA['channels']
        if citem.get('id') is None: citem['id'] = Globals._getChannelID(citem.get('name'), citem.get('path'), citem.get('number'), uuid=self.channelDATA.get('uuid'))
        return tuple(next(((idx, eitem) for idx, eitem in enumerate(channels) if citem['id'] == eitem.get('id', '')), (None,{})))
                    
                    
    def _channelManager(self) -> bytes:
        """Load and return the channel manager HTML template with placeholders replaced."""
        with FileAccess.stream(MANAGERPATH, "r") as fle:
            html_content = fle.read()
        html_content = html_content.replace("{{ channel_limit }}", str(CHANNEL_LIMIT))
        html_content = html_content.replace("{{ media_loc }}",    MEDIA_LOC)
        html_content = html_content.replace("{{ remote_host }}",  Globals.properties.getRemoteHost())
        return html_content.encode(encoding=DEFAULT_ENCODING)


def migrateAutotuneToUser(restart: bool = True) -> bool:
    """When autotune is disabled, copy the last known autotuned channel set into
    the user key so disabling never leaves an empty manager/M3U/PVR.

    Sources, in order:
      1. the live autotune key,
      2. the has.Channels property snapshot, keyed by the (versioned) autotune key,
      3. the Channels.Changed backup row (last saveChanges snapshot).
    (2) and (3) exist because a stale GC-time save used to zero the live key —
    both keys were found emptied while the snapshots still held the channels.

    Guards: never migrates while Enable_Autotune is on; never clobbers a
    non-empty user key. Returns True when channels were copied.
    """
    try:
        if Globals.settings.getSettingBool('Enable_Autotune'): return False
        if Channels(CHANNEL_KEY_USER).getChannels():           return False # user already has channels - never clobber
        auto = Channels(CHANNEL_KEY_AUTOTUNE)
        src  = auto.getChannels()
        if not src:
            snap = Globals.settings.getCacheSetting('%s.has.Channels' % (ADDON_ID), default={}) or {}
            src  = (snap.get(auto.channelKEY) or {}).get('channels') or []
        if not src:
            src = (Globals.settings.getCacheSetting(CHANNEL_KEY_CHANGED, FileAccess._getMD5(CHANNEL_KEY_CHANGED)) or {}).get('channels') or []
        if not src: return False
        Channels(CHANNEL_KEY_USER, writable=True).setChannels(src)
        Globals.properties.setBackup(CHANNEL_KEY_USER, src)
        if restart: Globals.properties.setPendingRestart()
        LOG('migrateAutotuneToUser, copied %d channels to user config%s' % (len(src), ' + pending restart' if restart else ''), xbmc.LOGINFO)
        return True
    except Exception as e:
        LOG('migrateAutotuneToUser failed: %s' % e, xbmc.LOGWARNING)
        return False
        