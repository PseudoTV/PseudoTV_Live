#   Copyright (C) 2026 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-

from typing import Any, Optional
from variables   import *
from _services   import _Service

class Multiroom(object):
    _default_data = None   # memoized static default template (SERVERFLE_DEFAULT)

    def __init__(self, sysARG: list = sys.argv, service: Optional[_Service] = None):
        if service is None: service = _Service()
        self.log('__init__, sysARG = %s'%(sysARG))
        self.sysARG     = sysARG
        self.service    = service
        self.jsonRPC    = service.jsonRPC
        self.cache      = service.cache
        if Multiroom._default_data is None:
            Multiroom._default_data = FileAccess.getJSON(SERVERFLE_DEFAULT)
        # Deep-copy the memoized template: _load()/addServer() mutate this
        # instance's structure and must never alias the shared copy.
        import copy
        self.serverData = copy.deepcopy(Multiroom._default_data)
        self.serverKEY  = f'{SERVERS_KEY}.{self.serverData.get("version","0.0.0")}'
        self.serverData.update(self._load())


    def log(self, msg: str, level: int = xbmc.LOGDEBUG):
        LOG(f"{self.__class__.__name__}: {msg}", level)


    def _getStatus(self) -> bool:
        self.log('_getStatus')
        return self.jsonRPC.getSettingValue("services.zeroconf",default=False,cache=True)


    def _load(self) -> dict:
        servers = Globals.settings.getCacheSetting(self.serverKEY, FileAccess._getMD5(self.serverKEY), default=self.serverData)
        Globals.properties.setHasServers(len(servers.get('servers',{})) > 0)
        Globals.settings.setSetting('Select_server','|'.join([LANGUAGE(32211).format(color={True:'green',False:'red'}[server.get('online',False)],text=server.get('name')) for server in self.getEnabled(servers.get('servers',{}))]))
        self.log('_load, servers = %s'%(len(servers.get('servers',{}))))
        return servers

       
    def _save(self) -> bool:
        self.log('_save, servers = %s'%(len(self.serverData.get('servers',{}))))
        return Globals.settings.setCacheSetting(self.serverKEY, self.serverData, FileAccess._getMD5(self.serverKEY), -1)
            
            
    def _toastServer(self, server, online=False):
        Globals.dialog.notificationDialog('%s: %s'%(server['name'],LANGUAGE(32211).format(color={True:'green',False:'red'}[online],text={True:LANGUAGE(32158),False:LANGUAGE(32253)}[online])))
            
            
    def _chkServers(self, servers: Optional[dict] = None):
        if servers is None: servers = self.serverData.get('servers',{})
        self.log(f'_chkServers, servers = {servers}')
        for server in servers:
            if not (server.get('enabled') or self.get('host')): continue
            online =  self.pingHost(server.get('host'))
            if server.get('online',False) != online: self._toastServer(server, online)
            server['online'] = online
            # if online:
                #chk settings for resources? trigger channel updates?
        return servers
            
            
    def _setServers(self, servers: Optional[dict] = None) -> bool:
        if servers is None: servers = self.serverData['servers']
        self.serverData["servers"] = servers
        Globals.properties.setHasServers(len(servers) > 0)
        Globals.settings.setSetting('Select_server','|'.join([LANGUAGE(32211).format(color={True:'green',False:'red'}[server.get('online',False)],text=server.get('name')) for server in self.getEnabled(servers)]))
        self.log('_setServers, servers = %s'%(len(servers)))
        return self._save()
            
            
    def getEnabled(self, servers: Optional[dict] = None) -> list:
        if servers is None: servers = self.serverData.get('servers',{})
        enabled = [server for server in list(servers.values()) if server.get('enabled',False)]
        Globals.properties.setEnabledServers(len(enabled) > 0)
        self.log('getEnabled = %s'%(len(enabled)))
        return enabled
            

    def pingHost(self, host: str, timeout: float = 2.0) -> bool:
        """Ping a host in 'host:port' format. Returns True if reachable."""
        try:
            h, p = host.split(':')
            socket.create_connection((h, int(p)), timeout=timeout)
            return True
        except Exception: 
            return False
            
            
    def getRemote(self, remote: str) -> Any:
        self.log("getRemote, remote = %s"%(remote))
        return self.jsonRPC.requestURL(remote, header={'Accept':'application/json'})

        
    def addServer(self, payload: dict = {}):
        if isinstance(payload,dict) and payload.get('name') and payload.get('host'):
            payload['online'] = True
            servers = self.serverData.get('servers',{})
            server  = servers.get(payload.get('name'),{})
            if not server:
                #New Instance
                servers[payload['name']] = payload
                self.log('addServer, adding server = %s'%(payload))
                if payload.get('host') != Globals.properties.getRemoteHost(): 
                    if Globals.settings.getSettingBool('Auto_Allow_Servers') or Globals.dialog.yesnoDialog('[B]%s:[/B] %s\n%s'%(LANGUAGE(32047),payload.get('name'),LANGUAGE(30129))):
                        payload['enabled'] = True
                        Globals.settings.setPVRRemote(payload.get('host'),payload.get('name')) #add Remote IPTV Simple config
                    else: payload['enabled'] = False
                else: payload['enabled'] = True
            else:
                #Existing Instance
                instancePath = Globals.settings.instances.hasPVRInstance(server.get('name'))
                payload['enabled'] = server.get('enabled',False)
                if instancePath is None or (payload.get('md5') != server.get('md5',str(random.random()))):#something changed!
                    if payload['enabled']:
                        if payload['online'] != server.get('online',False): self._toastServer(payload, payload['online'])
                        Globals.settings.setPVRRemote(payload.get('host'),payload.get('name')) #update Remote IPTV Simple config
                        
                        if payload.get('settings') != server.get('settings'):
                            [Globals.settings.hasAddon(id) for _,addons in list(payload.get('settings',{}).items()) for id in addons if id.startswith(('resource','plugin'))]
                            
                        if payload.get('resume') != server.get('resume'):
                            [self.getRemote(url) for url in payload.get('resume',[])]
                            
                    else: FileAccess.delete(instancePath) #del IPTV Simple config
                    servers[payload['name']] = payload
                    self.log('addServer, updating server = %s'%(payload))
            self._setServers(servers)


    def _delServer(self, servers: dict = {}):
        self.log('_delServer')
        def __buildMenuItem(payload):
            idx = list(servers.values()).index(payload)
            return Globals.listitems.buildMenuListItem(payload.get('name'),'%s - %s: Channels (%s)'%(LANGUAGE(32211).format(color={True:'green',False:'red'}[payload.get('online',False)],text={True:LANGUAGE(32158),False:LANGUAGE(32253)}[payload.get('online',False)]),payload.get('host'),len(payload.get('channels',[]))),icon=Globals._getDummyIcon(str(idx+1)),url=FileAccess.dumpJSON(payload))
      
        with Globals.builtin.busy_dialog():
            if not servers: servers = self.serverData.get('servers',{})
            lizLST = poolit(__buildMenuItem)(list(servers.values()))

        selects = Globals.dialog.selectDialog(lizLST,LANGUAGE(32183))
        if not selects is None:
            with Globals.builtin.busy_dialog():
                keys = list(servers.keys())
                remaining = {k: servers[k] for i, k in enumerate(keys) if i not in selects}
                if self._setServers(remaining):
                    return Globals.dialog.notificationDialog(LANGUAGE(30046))


    def _selServer(self):
        self.log('_selServer')
        def __buildMenuItem(payload): #build menu item
            return Globals.listitems.buildMenuListItem(payload.get('name'),'%s - %s: Channels (%s)'%(LANGUAGE(32211).format(color={True:'green',False:'red'}[payload.get('online',False)],text={True:LANGUAGE(32158),False:LANGUAGE(32253)}[payload.get('online',False)]),payload.get('host'),len(payload.get('channels',[]))),icon=Globals._getDummyIcon(str(list(servers.values()).index(payload)+1)),url=FileAccess.dumpJSON(payload))
      
        with Globals.builtin.busy_dialog():
            friendly = Globals.properties.getFriendlyName()
            servers  = self.serverData.get('servers',{})
            if friendly in servers: servers.pop(friendly)
            lizLST = []
            lizLST.extend(poolit(__buildMenuItem)(list(servers.values())))
            if len(lizLST) > 0: lizLST.insert(0,Globals.listitems.buildMenuListItem('[COLOR=white][B]- %s[/B][/COLOR]'%(LANGUAGE(30046)),LANGUAGE(33046))) #remove server menu item
            else: return
            
        if not Globals.properties.isRunning('Multiroom._selServer'):
            with Globals.properties.chkRunning('Multiroom._selServer'):
                selects = Globals.dialog.selectDialog(lizLST,LANGUAGE(30130),preselect=[idx for idx, listitem in enumerate(lizLST) if FileAccess.loadJSON(listitem.getPath(), skip_cache=True).get('enabled',False)])
                if not selects is None:
                    if 0 in selects: return self._delServer(servers)
                    else:
                        changed = False
                        for idx, liz in enumerate(lizLST):
                            with Globals.builtin.busy_dialog():
                                if   idx == 0: continue
                                elif idx in selects:
                                    if not servers[liz.getLabel()].get('enabled',False):
                                        changed = True
                                        servers[liz.getLabel()]['enabled'] = True
                                        Globals.dialog.notificationDialog(LANGUAGE(30099).format(name=liz.getLabel()))
                                    if not Globals.settings.instances.hasPVRInstance(liz.getLabel()): 
                                        if Globals.settings.setPVRRemote(servers[liz.getLabel()].get('host'),liz.getLabel()):
                                            Globals.properties.setPropTimer('chkPVRRefresh')#refresh pvr guide
                                else:
                                    if servers[liz.getLabel()].get('enabled',False):
                                        changed = True
                                        servers[liz.getLabel()]['enabled'] = False
                                        Globals.dialog.notificationDialog(LANGUAGE(30100).format(name=liz.getLabel()))
                                    try: FileAccess.delete(Globals.settings.instances.hasPVRInstance(liz.getLabel()))
                                    except Exception as e: self.log('delete PVR instance failed: %s' % e, xbmc.LOGDEBUG)
                        if changed: self._setServers(servers)


    def _chkZeroConf(self):
        self.log('_chkZeroConf')
        if Globals.settings.getSetting('ZeroConf_Status') == '[COLOR=red][B]%s[/B][/COLOR]'%(LANGUAGE(32253)):
            if Globals.builtin.getInfoLabel('System.Platform.Windows'): #prompt windows users to dl bonjour service.
                Globals.builtin.executebuiltin(f'RunScript(special://home/addons/{ADDON_ID}/resources/lib/utilities.py, Show_ZeroConf_QR)')
            if Globals.dialog.yesnoDialog(message=LANGUAGE(30129)):
                if self.jsonRPC.setSettingValue("services.zeroconf",True,queue=False):
                    Globals.dialog.notificationDialog(LANGUAGE(32219).format(name=LANGUAGE(30035)))
                    self.service._que(self.service.tasks.chkDiscovery, 1)
        else: Globals.dialog.notificationDialog(LANGUAGE(32219).format(name=LANGUAGE(30034)))
                            
        
    def _run(self) -> Any:
        try:    param = self.sysARG[1]
        except Exception: param = None
        if param == 'Enable_ZeroConf': 
            ctl = (4,6)  # sharing -> ZeroConf_Status
            self._chkZeroConf()
        elif param == 'Select_Servers': 
            ctl = (4,7)  # sharing -> Select_server
            Globals.settings.setSettingBool('Enable_Client',True)
            self._selServer()
        return Globals._openSettings(ctl)

if __name__ == '__main__': Multiroom(sys.argv,None)._run()
    